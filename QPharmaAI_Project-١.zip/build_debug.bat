@echo off
echo ==========================================
echo   Q-Pharma AI - Build Script
echo ==========================================
echo.

REM Check Java
java -version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Java not found! Please install JDK 17
    pause
    exit /b 1
)

REM Check Android SDK
if not defined ANDROID_HOME (
    echo [ERROR] ANDROID_HOME not set!
    echo Please install Android Studio and set ANDROID_HOME
    pause
    exit /b 1
)

echo [1/3] Cleaning project...
gradlew clean

echo [2/3] Building Debug APK...
gradlew assembleDebug

echo [3/3] Build complete!
echo.
echo APK location: app\build\outputs\apk\debug\app-debug.apk
echo.
pause
