# Q-Pharma AI - دليل التثبيت

## ⚠️ ملاحظة مهمة
هذا المشروع يحتاج إلى **Android Studio** لبناء ملف APK. لا يمكن تشغيله مباشرة بدون بناء.

---

## 📋 المتطلبات

1. **كمبيوتر** (Windows / Mac / Linux)
2. **Android Studio** (مجاني) - [تحميل من هنا](https://developer.android.com/studio)
3. **مساحة فارغة**: 10 GB على الأقل
4. **اتصال إنترنت** للتحميل

---

## 🚀 خطوات التثبيت

### الخطوة 1: تحميل Android Studio
```
https://developer.android.com/studio
```
- اختر نسختك (Windows/Mac/Linux)
- ثبت البرنامج (Next → Next → Finish)

### الخطوة 2: فتح المشروع
1. افتح Android Studio
2. اختر **"Open"** (ليس New Project)
3. انتقل إلى مجلد **QPharmaAI**
4. اضغط **OK**

### الخطوة 3: انتظر المزامنة
- Android Studio سيحمل المكتبات تلقائياً
- قد يستغرق 10-30 دقيقة (حسب سرعة الإنترنت)
- انتظر حتى تختفي رسالة "Syncing..."

### الخطوة 4: بناء APK
**الطريقة الأولى (الأسهل):**
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```

**الطريقة الثانية (باستخدام Terminal):**
```bash
# Windows:
build_debug.bat

# Mac/Linux:
chmod +x build_debug.sh
./build_debug.sh
```

### الخطوة 5: تثبيت على الهاتف
1. افتح مجلد: `app/build/outputs/apk/debug/`
2. انسخ ملف `app-debug.apk` إلى هاتفك
3. على الهاتف: افتح الملف وثبت
4. فعّل "التثبيت من مصادر غير معروفة" إذا طُلب

---

## 🔧 حل المشاكل الشائعة

### "Gradle sync failed"
```
File → Invalidate Caches → Invalidate and Restart
```

### "SDK not found"
```
Tools → SDK Manager → Install Android SDK 34
```

### "JDK not found"
```
File → Settings → Build → Gradle → Set JDK path
```

### "Out of memory"
```
افتح: gradle.properties
غير: org.gradle.jvmargs=-Xmx4096m
إلى:  org.gradle.jvmargs=-Xmx8192m
```

---

## 📱 متطلبات الهاتف

| المواصفة | الحد الأدنى |
|----------|-------------|
| Android | 8.0 (API 26) |
| RAM | 3 GB |
| Storage | 200 MB |
| Camera | مطلوبة للتصوير |
| Microphone | مطلوب للصوت |

---

## 🆘 الدعم

إذا واجهت مشاكل، أرسل:
1. لقطة شاشة للخطأ
2. نسخة Android Studio
3. نوع نظام التشغيل

---

**Q-Pharma AI v1.0.0** | نظام إدارة الصيدليات الذكي
