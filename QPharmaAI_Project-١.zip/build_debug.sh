#!/bin/bash
echo "=========================================="
echo "  Q-Pharma AI - Build Script"
echo "=========================================="
echo ""

# Check Java
if ! command -v java &> /dev/null; then
    echo "[ERROR] Java not found! Please install JDK 17"
    exit 1
fi

# Check Android SDK
if [ -z "$ANDROID_HOME" ]; then
    echo "[ERROR] ANDROID_HOME not set!"
    echo "Please install Android Studio and set ANDROID_HOME"
    exit 1
fi

echo "[1/3] Cleaning project..."
./gradlew clean

echo "[2/3] Building Debug APK..."
./gradlew assembleDebug

echo "[3/3] Build complete!"
echo ""
echo "APK location: app/build/outputs/apk/debug/app-debug.apk"
echo ""
