
//================================================================================
// FILE: data/entity/Patient.kt
//================================================================================
package com.qpharma.ai.data.entity

import androidx.room.*
import java.util.Date

@Entity(tableName = "patients", indices = [Index(value = ["phone"], unique = true)])
data class Patient(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val name: String,
    val phone: String? = null,
    val gender: String? = null,           // "male" | "female"
    val birthDate: Date? = null,
    val age: Int? = null,
    val chronicDiseases: String? = null,   // JSON array string
    val allergies: String? = null,         // JSON array string
    val doctorName: String? = null,
    val notes: String? = null,
    val qrCode: String? = null,            // Generated unique QR
    val loyaltyPoints: Int = 0,
    val creditLimit: Double = 0.0,
    val customerType: String = "regular",   // "chronic" | "supplies" | "regular" | "vip"

    val createdAt: Date = Date(),
    val updatedAt: Date = Date(),
    val isActive: Boolean = true,
    val syncStatus: String = "pending"     // "synced" | "pending" | "conflict"
)

//================================================================================
// FILE: data/entity/Product.kt
//================================================================================
package com.qpharma.ai.data.entity

import androidx.room.*
import java.util.Date

@Entity(tableName = "products", indices = [Index(value = ["barcode"], unique = true)])
data class Product(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val name: String,
    val genericName: String? = null,
    val barcode: String? = null,
    val category: String? = null,
    val subcategory: String? = null,
    val purchasePrice: Double = 0.0,
    val salePrice: Double = 0.0,
    val profitMargin: Double = 0.0,        // Auto-calculated
    val quantity: Int = 0,
    val minStock: Int = 5,
    val expiryDate: Date? = null,

    @ColumnInfo(name = "supplier_id")
    val supplierId: Long? = null,

    val isActive: Boolean = true,
    val createdAt: Date = Date()
)

//================================================================================
// FILE: data/entity/Invoice.kt
//================================================================================
package com.qpharma.ai.data.entity

import androidx.room.*
import java.util.Date

@Entity(
    tableName = "invoices",
    foreignKeys = [
        ForeignKey(
            entity = Patient::class,
            parentColumns = ["id"],
            childColumns = ["customer_id"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = Cashbox::class,
            parentColumns = ["id"],
            childColumns = ["cashbox_id"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index(value = ["invoice_number"], unique = true)]
)
data class Invoice(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val invoiceNumber: String,               // Auto-generated: INV-20260721-0001

    @ColumnInfo(name = "customer_id")
    val customerId: Long,

    val totalAmount: Double = 0.0,
    val discountAmount: Double = 0.0,
    val netAmount: Double = 0.0,
    val paidAmount: Double = 0.0,
    val remaining: Double = 0.0,
    val paymentStatus: String = "unpaid",    // "paid" | "partial" | "unpaid"

    @ColumnInfo(name = "cashbox_id")
    val cashboxId: Long? = null,

    val invoiceType: String = "sale",      // "sale" | "return" | "purchase"
    val createdAt: Date = Date()
)

@Entity(
    tableName = "invoice_items",
    foreignKeys = [
        ForeignKey(
            entity = Invoice::class,
            parentColumns = ["id"],
            childColumns = ["invoice_id"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = Product::class,
            parentColumns = ["id"],
            childColumns = ["product_id"],
            onDelete = ForeignKey.RESTRICT
        )
    ]
)
data class InvoiceItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "invoice_id")
    val invoiceId: Long,

    @ColumnInfo(name = "product_id")
    val productId: Long,

    val quantity: Int = 1,
    val unitPrice: Double = 0.0,
    val totalPrice: Double = 0.0,
    val profitPerUnit: Double = 0.0,
    val totalProfit: Double = 0.0,
    val discountApplied: Double = 0.0
)

//================================================================================
// FILE: data/entity/Cashbox.kt
//================================================================================
package com.qpharma.ai.data.entity

import androidx.room.*
import java.util.Date

@Entity(tableName = "cashboxes")
data class Cashbox(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val name: String,                        // "الصندوق النقدي" | "محفظة الكريمي"
    val type: String,                        // "cash" | "wallet" | "bank"
    val balance: Double = 0.0,
    val currency: String = "YER",
    val isActive: Boolean = true,
    val createdAt: Date = Date()
)

@Entity(
    tableName = "cashbox_transactions",
    foreignKeys = [
        ForeignKey(
            entity = Cashbox::class,
            parentColumns = ["id"],
            childColumns = ["cashbox_id"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class CashboxTransaction(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "cashbox_id")
    val cashboxId: Long,

    val transactionType: String,             // "income" | "expense" | "transfer"
    val amount: Double = 0.0,
    val balanceAfter: Double = 0.0,
    val referenceType: String? = null,     // "invoice" | "voucher" | "manual"
    val referenceId: Long? = null,
    val description: String? = null,
    val createdAt: Date = Date()
)

//================================================================================
// FILE: data/entity/Prescription.kt
//================================================================================
package com.qpharma.ai.data.entity

import androidx.room.*
import java.util.Date

@Entity(
    tableName = "prescriptions",
    foreignKeys = [
        ForeignKey(
            entity = Patient::class,
            parentColumns = ["id"],
            childColumns = ["customer_id"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class Prescription(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "customer_id")
    val customerId: Long,

    val inputMethod: String,                 // "manual" | "voice" | "camera" | "pdf"
    val imagePath: String? = null,
    val voicePath: String? = null,
    val pdfPath: String? = null,
    val aiExtractedText: String? = null,
    val aiConfidence: Float = 0.0f,
    val status: String = "draft",            // "draft" | "confirmed" | "cancelled"
    val createdAt: Date = Date()
)

@Entity(
    tableName = "prescription_items",
    foreignKeys = [
        ForeignKey(
            entity = Prescription::class,
            parentColumns = ["id"],
            childColumns = ["prescription_id"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class PrescriptionItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "prescription_id")
    val prescriptionId: Long,

    val drugName: String,
    val concentration: String? = null,       // "500mg" | "10ml"
    val quantity: Int = 1,
    val dosage: String? = null,            // "1 حبة"
    val frequency: String? = null,         // "3 مرات يومياً"
    val durationDays: Int? = null,
    val packageQty: Int? = null,             // 60 حبة في العلبة
    val packageType: String? = null,       // "قرص" | "شراب" | "حقنة"
    val aiCalculatedEndDate: Date? = null,  // Auto-calculated
    val createdAt: Date = Date()
)

//================================================================================
// FILE: data/entity/MedicationReminder.kt
//================================================================================
package com.qpharma.ai.data.entity

import androidx.room.*
import java.util.Date

@Entity(
    tableName = "medication_reminders",
    foreignKeys = [
        ForeignKey(
            entity = Patient::class,
            parentColumns = ["id"],
            childColumns = ["customer_id"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = PrescriptionItem::class,
            parentColumns = ["id"],
            childColumns = ["prescription_item_id"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class MedicationReminder(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "customer_id")
    val customerId: Long,

    @ColumnInfo(name = "prescription_item_id")
    val prescriptionItemId: Long,

    val drugName: String,
    val reminderDate: Date,
    val reminderTime: String = "09:00",      // HH:mm format
    val message: String? = null,
    val channel: String = "whatsapp",        // "whatsapp" | "sms" | "notification"
    val status: String = "scheduled",        // "scheduled" | "sent" | "cancelled"
    val autoCreated: Boolean = true,         // TRUE = created by AI silently
    val daysBeforeRunout: Int = 3,           // Configurable safety margin
    val createdAt: Date = Date()
)

//================================================================================
// FILE: data/entity/Document.kt
//================================================================================
package com.qpharma.ai.data.entity

import androidx.room.*
import java.util.Date

@Entity(tableName = "documents")
data class Document(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val fileName: String,
    val filePath: String,
    val fileType: String,                    // "pdf" | "excel" | "image"
    val sourceType: String,                  // "imported" | "scanned" | "generated"
    val pageCount: Int? = null,
    val extractedData: String? = null,       // JSON string of extracted tables
    val excelExportPath: String? = null,
    val processingStatus: String = "pending", // "pending" | "processing" | "completed" | "failed"
    val aiModelUsed: String? = null,
    val createdAt: Date = Date()
)

//================================================================================
// FILE: data/entity/Supplier.kt
//================================================================================
package com.qpharma.ai.data.entity

import androidx.room.*
import java.util.Date

@Entity(tableName = "suppliers")
data class Supplier(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val name: String,
    val phone: String? = null,
    val email: String? = null,
    val address: String? = null,
    val balance: Double = 0.0,
    val creditLimit: Double = 0.0,
    val paymentTerms: String? = null,
    val isActive: Boolean = true,
    val createdAt: Date = Date()
)

@Entity(
    tableName = "payment_receipts",
    foreignKeys = [
        ForeignKey(
            entity = Supplier::class,
            parentColumns = ["id"],
            childColumns = ["supplier_id"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class PaymentReceipt(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "supplier_id")
    val supplierId: Long,

    val imagePath: String,
    val aiExtractedAmount: Double? = null,
    val aiExtractedReference: String? = null,
    val aiExtractedDate: Date? = null,
    val aiConfidence: Float = 0.0f,
    val voucherType: String = "payment",     // "payment" | "receipt"
    val voucherStatus: String = "draft",     // "draft" | "approved" | "rejected"
    val approvedBy: String? = null,
    val approvedAt: Date? = null,
    val createdAt: Date = Date()
)

//================================================================================
// FILE: data/entity/MarketingCampaign.kt
//================================================================================
package com.qpharma.ai.data.entity

import androidx.room.*
import java.util.Date

@Entity(tableName = "marketing_campaigns")
data class MarketingCampaign(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val campaignName: String,
    val campaignType: String,                // "holiday" | "condolence" | "jumaa" | "promo" | "awareness"
    val targetAudience: String? = null,        // JSON: customer segments
    val targetProducts: String? = null,      // JSON: product IDs
    val discountPercent: Double? = null,
    val startDate: Date? = null,
    val endDate: Date? = null,
    val status: String = "draft",            // "draft" | "active" | "completed" | "cancelled"
    val aiGenerated: Boolean = false,
    val createdAt: Date = Date()
)

@Entity(
    tableName = "marketing_designs",
    foreignKeys = [
        ForeignKey(
            entity = MarketingCampaign::class,
            parentColumns = ["id"],
            childColumns = ["campaign_id"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class MarketingDesign(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "campaign_id")
    val campaignId: Long,

    val designType: String,                  // "poster" | "story" | "banner"
    val imagePath: String,
    val promptUsed: String? = null,
    val brandKitApplied: Boolean = true,
    val scheduleDate: Date? = null,
    val scheduleTime: String? = null,
    val publishStatus: String = "scheduled", // "scheduled" | "published" | "failed"
    val publishedAt: Date? = null
)

//================================================================================
// FILE: data/entity/MessageTemplate.kt
//================================================================================
package com.qpharma.ai.data.entity

import androidx.room.*
import java.util.Date

@Entity(tableName = "message_templates")
data class MessageTemplate(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val templateName: String,
    val templateType: String,                 // "reminder" | "promo" | "greeting" | "custom"
    val subject: String? = null,
    val body: String,                         // With {{variables}}
    val variables: String? = null,            // JSON: ["customer_name", "drug_name"]
    val channel: String = "whatsapp",       // "whatsapp" | "sms" | "notification"
    val language: String = "ar",
    val isAiGenerated: Boolean = false,
    val createdAt: Date = Date()
)

@Entity(
    tableName = "sent_messages",
    foreignKeys = [
        ForeignKey(
            entity = MessageTemplate::class,
            parentColumns = ["id"],
            childColumns = ["template_id"],
            onDelete = ForeignKey.SET_NULL
        ),
        ForeignKey(
            entity = Patient::class,
            parentColumns = ["id"],
            childColumns = ["customer_id"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class SentMessage(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "template_id")
    val templateId: Long? = null,

    @ColumnInfo(name = "customer_id")
    val customerId: Long,

    val channel: String,
    val messageBody: String,
    val status: String = "pending",          // "pending" | "sent" | "delivered" | "failed"
    val sentAt: Date? = null,
    val deliveredAt: Date? = null,
    val readAt: Date? = null,
    val errorMessage: String? = null
)

//================================================================================
// FILE: data/entity/AutomationRule.kt
//================================================================================
package com.qpharma.ai.data.entity

import androidx.room.*
import java.util.Date

@Entity(tableName = "automation_rules")
data class AutomationRule(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val ruleName: String,
    val triggerType: String,                  // "schedule" | "event" | "condition"
    val triggerCondition: String,              // JSON condition config
    val actionType: String,                    // "sync" | "export" | "notify" | "ai_process"
    val actionConfig: String,                  // JSON action config
    val scheduleCron: String? = null,          // Cron expression for scheduled rules
    val isActive: Boolean = true,
    val lastRun: Date? = null,
    val nextRun: Date? = null
)
