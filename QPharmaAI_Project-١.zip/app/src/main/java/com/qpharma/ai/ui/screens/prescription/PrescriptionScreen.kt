
//================================================================================
// FILE: ui/screens/prescription/PrescriptionScreen.kt
//================================================================================
package com.qpharma.ai.ui.screens.prescription

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.qpharma.ai.ui.theme.QPharmaColors
import com.qpharma.ai.ui.viewmodel.*
import com.qpharma.ai.data.entity.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrescriptionScreen(
    viewModel: PrescriptionViewModel = hiltViewModel(),
    customerId: Long? = null,
    onNavigateBack: () -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()
    val processingState by viewModel.processingState.collectAsState()
    val context = LocalContext.current

    // Camera launcher
    var capturedImageUri by remember { mutableStateOf<Uri?>(null) }
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && capturedImageUri != null) {
            viewModel.captureImage(capturedImageUri!!)
        }
    }

    // Gallery launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { viewModel.captureImage(it) }
    }

    // PDF launcher
    val pdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { viewModel.setPdfPath(it.path ?: "") }
    }

    // Voice recording state
    var isRecording by remember { mutableStateOf(false) }
    var showInputMethodSelector by remember { mutableStateOf(true) }
    var showManualEntry by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "وصفة جديدة",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = QPharmaColors.Background
                )
            )
        },
        containerColor = QPharmaColors.Background
    ) { padding ->

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when {
                // ===== PROCESSING OVERLAY =====
                processingState is ProcessingState.Processing -> {
                    ProcessingOverlay(state = processingState as ProcessingState.Processing)
                }

                // ===== SUCCESS OVERLAY =====
                processingState is ProcessingState.Success -> {
                    SuccessOverlay(
                        state = processingState as ProcessingState.Success,
                        onDismiss = { viewModel.cancelProcessing() }
                    )
                }

                // ===== ERROR OVERLAY =====
                processingState is ProcessingState.Error -> {
                    ErrorOverlay(
                        state = processingState as ProcessingState.Error,
                        onRetry = { viewModel.retryProcessing() },
                        onDismiss = { viewModel.cancelProcessing() }
                    )
                }

                // ===== INPUT METHOD SELECTOR =====
                showInputMethodSelector -> {
                    InputMethodSelector(
                        onCameraClick = {
                            val uri = createImageUri(context)
                            capturedImageUri = uri
                            cameraLauncher.launch(uri)
                            showInputMethodSelector = false
                        },
                        onGalleryClick = {
                            galleryLauncher.launch("image/*")
                            showInputMethodSelector = false
                        },
                        onVoiceClick = {
                            isRecording = true
                            showInputMethodSelector = false
                        },
                        onPdfClick = {
                            pdfLauncher.launch("application/pdf")
                            showInputMethodSelector = false
                        },
                        onManualClick = {
                            showManualEntry = true
                            showInputMethodSelector = false
                        }
                    )
                }

                // ===== MANUAL ENTRY FORM =====
                showManualEntry -> {
                    ManualEntryForm(
                        onAddDrug = { drug ->
                            viewModel.addManualDrug(drug)
                            showManualEntry = false
                        },
                        onCancel = { showManualEntry = false }
                    )
                }

                // ===== PREVIEW & CONFIRMATION =====
                else -> {
                    PrescriptionPreview(
                        uiState = uiState,
                        onConfirm = { viewModel.confirmPrescription() },
                        onCancel = { viewModel.cancelProcessing() },
                        onAddMore = { showManualEntry = true }
                    )
                }
            }
        }
    }
}

// ===== INPUT METHOD SELECTOR =====
@Composable
private fun InputMethodSelector(
    onCameraClick: () -> Unit,
    onGalleryClick: () -> Unit,
    onVoiceClick: () -> Unit,
    onPdfClick: () -> Unit,
    onManualClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "اختر طريقة الإدخال",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = QPharmaColors.TextPrimary,
            textAlign = TextAlign.Center
        )

        Text(
            "يمكنك إدخال الوصفة بعدة طرق",
            style = MaterialTheme.typography.bodyMedium,
            color = QPharmaColors.TextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
        )

        // Grid of input methods
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                InputMethodCard(
                    icon = Icons.Default.CameraAlt,
                    title = "تصوير الوصفة",
                    subtitle = "OCR بالذكاء الاصطناعي",
                    color = QPharmaColors.Primary,
                    modifier = Modifier.weight(1f),
                    onClick = onCameraClick
                )
                InputMethodCard(
                    icon = Icons.Default.PhotoLibrary,
                    title = "اختيار من المعرض",
                    subtitle = "صورة محفوظة",
                    color = QPharmaColors.Secondary,
                    modifier = Modifier.weight(1f),
                    onClick = onGalleryClick
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                InputMethodCard(
                    icon = Icons.Default.Mic,
                    title = "تسجيل صوتي",
                    subtitle = "وصف الجرعة بالصوت",
                    color = QPharmaColors.Info,
                    modifier = Modifier.weight(1f),
                    onClick = onVoiceClick
                )
                InputMethodCard(
                    icon = Icons.Default.PictureAsPdf,
                    title = "ملف PDF",
                    subtitle = "وصفة إلكترونية",
                    color = QPharmaColors.Warning,
                    modifier = Modifier.weight(1f),
                    onClick = onPdfClick
                )
            }

            InputMethodCard(
                icon = Icons.Default.Edit,
                title = "إدخال يدوي",
                subtitle = "كتابة تفاصيل الدواء",
                color = QPharmaColors.Success,
                modifier = Modifier.fillMaxWidth(),
                onClick = onManualClick
            )
        }
    }
}

@Composable
private fun InputMethodCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(120.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(26.dp))
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = QPharmaColors.TextPrimary,
                textAlign = TextAlign.Center
            )
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = QPharmaColors.TextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ===== MANUAL ENTRY FORM =====
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ManualEntryForm(
    onAddDrug: (ManualDrugInput) -> Unit,
    onCancel: () -> Unit
) {
    var drugName by remember { mutableStateOf("") }
    var concentration by remember { mutableStateOf("") }
    var dosage by remember { mutableStateOf("") }
    var frequency by remember { mutableStateOf("") }
    var packageQty by remember { mutableStateOf("") }
    var packageType by remember { mutableStateOf("قرص") }

    val packageTypes = listOf("قرص", "كبسولة", "شراب", "حقنة", "مرهم", "قطرة")
    var expanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                "إدخال الدواء يدوياً",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = QPharmaColors.TextPrimary
            )
        }

        item {
            OutlinedTextField(
                value = drugName,
                onValueChange = { drugName = it },
                label = { Text("اسم الدواء *") },
                placeholder = { Text("مثال: بانادول") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Medication, null) }
            )
        }

        item {
            OutlinedTextField(
                value = concentration,
                onValueChange = { concentration = it },
                label = { Text("التركيز") },
                placeholder = { Text("مثال: 500mg") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = dosage,
                    onValueChange = { dosage = it },
                    label = { Text("الجرعة") },
                    placeholder = { Text("مثال: حبتين") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = frequency,
                    onValueChange = { frequency = it },
                    label = { Text("التكرار") },
                    placeholder = { Text("3 مرات يومياً") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = packageQty,
                    onValueChange = { packageQty = it },
                    label = { Text("الكمية في العلبة") },
                    placeholder = { Text("60") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )

                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = packageType,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("النوع") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier.menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        packageTypes.forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type) },
                                onClick = {
                                    packageType = type
                                    expanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = onCancel,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("إلغاء")
                }
                Button(
                    onClick = {
                        if (drugName.isNotBlank()) {
                            onAddDrug(
                                ManualDrugInput(
                                    name = drugName,
                                    concentration = concentration.takeIf { it.isNotBlank() },
                                    dosage = dosage.takeIf { it.isNotBlank() },
                                    frequency = frequency.takeIf { it.isNotBlank() },
                                    packageQty = packageQty.toIntOrNull()
                                )
                            )
                        }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    enabled = drugName.isNotBlank()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إضافة الدواء")
                }
            }
        }
    }
}

// ===== PRESCRIPTION PREVIEW =====
@Composable
private fun PrescriptionPreview(
    uiState: PrescriptionUiState,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    onAddMore: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        // Header
        Text(
            "معاينة الوصفة",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = QPharmaColors.TextPrimary
        )

        Text(
            "الأدوية المستخرجة (${uiState.manualDrugs.size})",
            style = MaterialTheme.typography.bodyMedium,
            color = QPharmaColors.TextSecondary,
            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
        )

        // AI Processing badge
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = QPharmaColors.Primary.copy(alpha = 0.1f),
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = QPharmaColors.Primary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    "سيتم حساب مدة العلاج وتفعيل المنبهات تلقائياً",
                    style = MaterialTheme.typography.bodySmall,
                    color = QPharmaColors.Primary
                )
            }
        }

        // Drugs list
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(uiState.manualDrugs) { drug ->
                DrugPreviewCard(drug = drug)
            }
        }

        // Action buttons
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onConfirm,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = QPharmaColors.Primary)
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("تأكيد وحفظ الوصفة", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            OutlinedButton(
                onClick = onAddMore,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("إضافة دواء آخر")
            }

            TextButton(
                onClick = onCancel,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("إلغاء", color = QPharmaColors.TextSecondary)
            }
        }
    }
}

@Composable
private fun DrugPreviewCard(drug: ManualDrugInput) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(QPharmaColors.Primary.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Medication,
                    contentDescription = null,
                    tint = QPharmaColors.Primary,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    drug.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = QPharmaColors.TextPrimary
                )
                drug.concentration?.let {
                    Text(
                        "التركيز: $it",
                        style = MaterialTheme.typography.bodySmall,
                        color = QPharmaColors.TextSecondary
                    )
                }
                Row {
                    drug.dosage?.let {
                        SuggestionChip(
                            onClick = {},
                            label = { Text(it, fontSize = 11.sp) },
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }
                    drug.frequency?.let {
                        SuggestionChip(
                            onClick = {},
                            label = { Text(it, fontSize = 11.sp) }
                        )
                    }
                }
            }

            // Auto-calculation indicator
            drug.packageQty?.let { qty ->
                val days = calculateDays(qty, drug.dosage, drug.frequency)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "$days",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = QPharmaColors.Success
                    )
                    Text(
                        "يوم",
                        style = MaterialTheme.typography.bodySmall,
                        color = QPharmaColors.TextSecondary
                    )
                }
            }
        }
    }
}

private fun calculateDays(packageQty: Int, dosage: String?, frequency: String?): Int {
    val doseCount = dosage?.let { 
        when {
            it.contains("حبتين") || it.contains("2") -> 2
            it.contains("ثلاث") || it.contains("3") -> 3
            else -> 1
        }
    } ?: 1

    val freqCount = frequency?.let {
        when {
            it.contains("3") -> 3
            it.contains("2") || it.contains("مرتين") -> 2
            else -> 1
        }
    } ?: 1

    return packageQty / (doseCount * freqCount)
}

// ===== PROCESSING OVERLAY =====
@Composable
private fun ProcessingOverlay(state: ProcessingState.Processing) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(QPharmaColors.Background.copy(alpha = 0.95f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Animated progress indicator
            CircularProgressIndicator(
                modifier = Modifier.size(64.dp),
                color = QPharmaColors.Primary,
                strokeWidth = 4.dp
            )

            Text(
                state.message,
                style = MaterialTheme.typography.bodyLarge,
                color = QPharmaColors.TextPrimary,
                textAlign = TextAlign.Center
            )

            Text(
                "جاري التعرف على الأدوية وحساب الجرعات...",
                style = MaterialTheme.typography.bodyMedium,
                color = QPharmaColors.TextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ===== SUCCESS OVERLAY =====
@Composable
private fun SuccessOverlay(
    state: ProcessingState.Success,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(QPharmaColors.Background.copy(alpha = 0.95f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .padding(20.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(QPharmaColors.Success.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = QPharmaColors.Success,
                        modifier = Modifier.size(44.dp)
                    )
                }

                Text(
                    "تم بنجاح!",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = QPharmaColors.Success
                )

                Text(
                    state.message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = QPharmaColors.TextPrimary,
                    textAlign = TextAlign.Center
                )

                // Auto-reminder info
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = QPharmaColors.Primary.copy(alpha = 0.08f)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Alarm,
                            contentDescription = null,
                            tint = QPharmaColors.Primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "تم جدولة التذكير التلقائي قبل 3 أيام من نفاد الدواء",
                            style = MaterialTheme.typography.bodySmall,
                            color = QPharmaColors.Primary
                        )
                    }
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = QPharmaColors.Primary)
                ) {
                    Text("حسناً", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ===== ERROR OVERLAY =====
@Composable
private fun ErrorOverlay(
    state: ProcessingState.Error,
    onRetry: () -> Unit,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(QPharmaColors.Background.copy(alpha = 0.95f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .padding(20.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(QPharmaColors.Error.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Error,
                        contentDescription = null,
                        tint = QPharmaColors.Error,
                        modifier = Modifier.size(44.dp)
                    )
                }

                Text(
                    "حدث خطأ",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = QPharmaColors.Error
                )

                Text(
                    state.message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = QPharmaColors.TextPrimary,
                    textAlign = TextAlign.Center
                )

                if (state.canRetry) {
                    Button(
                        onClick = onRetry,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = QPharmaColors.Primary)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إعادة المحاولة")
                    }
                }

                TextButton(onClick = onDismiss) {
                    Text("إلغاء", color = QPharmaColors.TextSecondary)
                }
            }
        }
    }
}

// ===== UTILITY =====
private fun createImageUri(context: android.content.Context): Uri {
    // Implementation for creating a temporary image URI
    return Uri.EMPTY
}
