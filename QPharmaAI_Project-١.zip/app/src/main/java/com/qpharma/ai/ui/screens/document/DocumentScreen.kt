
//================================================================================
// FILE: ui/screens/document/DocumentScreen.kt
//================================================================================
package com.qpharma.ai.ui.screens.document

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.hilt.navigation.compose.hiltViewModel
import com.qpharma.ai.data.entity.Document
import com.qpharma.ai.ui.theme.QPharmaColors
import com.qpharma.ai.ui.viewmodel.DocumentViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentScreen(
    viewModel: DocumentViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()
    val documents by viewModel.documents.collectAsState()
    var showPdfPicker by remember { mutableStateOf(false) }
    var showCamera by remember { mutableStateOf(false) }
    var showVoiceEdit by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("المستندات والملفات", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = QPharmaColors.Background
                )
            )
        },
        containerColor = QPharmaColors.Background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Quick Actions
            item {
                Text(
                    "عمليات سريعة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                )
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ActionCard(
                        icon = Icons.Default.PictureAsPdf,
                        title = "PDF → Excel",
                        subtitle = "تحويل كشوف المخزون",
                        color = QPharmaColors.Error,
                        modifier = Modifier.weight(1f),
                        onClick = { showPdfPicker = true }
                    )
                    ActionCard(
                        icon = Icons.Default.CameraAlt,
                        title = "تصوير فاتورة",
                        subtitle = "OCR ذكي",
                        color = QPharmaColors.Primary,
                        modifier = Modifier.weight(1f),
                        onClick = { showCamera = true }
                    )
                }
            }

            item {
                ActionCard(
                    icon = Icons.Default.Mic,
                    title = "تعديل بالصوت",
                    subtitle = "أوامر صوتية على Excel",
                    color = QPharmaColors.Success,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { showVoiceEdit = true }
                )
            }

            // Processing status
            if (uiState.isProcessing) {
                item {
                    ProcessingCard(
                        progress = uiState.progress,
                        message = uiState.statusMessage
                    )
                }
            }

            // Document History
            item {
                Text(
                    "سجل المستندات",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
                )
            }

            items(documents) { doc ->
                DocumentHistoryCard(document = doc)
            }
        }
    }

    // PDF Picker Dialog
    if (showPdfPicker) {
        PdfPickerDialog(
            onDismiss = { showPdfPicker = false },
            onPdfSelected = { uri ->
                viewModel.selectPdfFile(uri)
                viewModel.convertPdfToExcel()
                showPdfPicker = false
            }
        )
    }

    // Voice Edit Dialog
    if (showVoiceEdit) {
        VoiceEditDialog(
            onDismiss = { showVoiceEdit = false },
            onVoiceCommand = { command ->
                viewModel.executeVoiceEdit(command)
                showVoiceEdit = false
            }
        )
    }
}

@Composable
private fun ActionCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(110.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = color, modifier = Modifier.size(26.dp))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(subtitle, fontSize = 12.sp, color = QPharmaColors.TextSecondary)
            }
        }
    }
}

@Composable
private fun ProcessingCard(progress: Int, message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Primary.copy(alpha = 0.08f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = QPharmaColors.Primary,
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(message, fontSize = 14.sp, color = QPharmaColors.Primary)
            }
            Spacer(modifier = Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.fillMaxWidth(),
                color = QPharmaColors.Primary,
                trackColor = QPharmaColors.SurfaceVariant
            )
            Text(
                "$progress%",
                modifier = Modifier.padding(top = 4.dp),
                fontSize = 12.sp,
                color = QPharmaColors.TextSecondary
            )
        }
    }
}

@Composable
private fun DocumentHistoryCard(document: Document) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val icon = when (document.fileType) {
                "pdf" -> Icons.Default.PictureAsPdf
                "excel" -> Icons.Default.TableChart
                else -> Icons.Default.InsertDriveFile
            }
            val iconColor = when (document.fileType) {
                "pdf" -> QPharmaColors.Error
                "excel" -> QPharmaColors.Success
                else -> QPharmaColors.Primary
            }

            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = iconColor, modifier = Modifier.size(22.dp))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(document.fileName, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(
                    "${document.fileType.uppercase()} | ${document.processingStatus}",
                    fontSize = 12.sp,
                    color = QPharmaColors.TextSecondary
                )
            }

            if (document.excelExportPath != null) {
                IconButton(onClick = { /* Open Excel */ }) {
                    Icon(Icons.Default.OpenInNew, null, tint = QPharmaColors.Success)
                }
            }
        }
    }
}

@Composable
private fun PdfPickerDialog(
    onDismiss: () -> Unit,
    onPdfSelected: (android.net.Uri) -> Unit
) {
    // Implementation using ActivityResultContracts
}

@Composable
private fun VoiceEditDialog(
    onDismiss: () -> Unit,
    onVoiceCommand: (String) -> Unit
) {
    var isRecording by remember { mutableStateOf(false) }
    var commandText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "تعديل بالأوامر الصوتية",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "قل مثلاً: "غيّر السعر في الصف 5 إلى 1500"",
                    style = MaterialTheme.typography.bodyMedium,
                    color = QPharmaColors.TextSecondary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Voice button
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(
                            if (isRecording) QPharmaColors.Error.copy(alpha = 0.2f)
                            else QPharmaColors.Primary.copy(alpha = 0.15f)
                        )
                        .clickable { isRecording = !isRecording },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
                        null,
                        tint = if (isRecording) QPharmaColors.Error else QPharmaColors.Primary,
                        modifier = Modifier.size(36.dp)
                    )
                }

                if (isRecording) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("جاري التسجيل...", color = QPharmaColors.Error)
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = commandText,
                    onValueChange = { commandText = it },
                    label = { Text("أو اكتب الأمر هنا") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء")
                    }
                    Button(
                        onClick = { onVoiceCommand(commandText) },
                        modifier = Modifier.weight(1f),
                        enabled = commandText.isNotBlank()
                    ) {
                        Text("تنفيذ")
                    }
                }
            }
        }
    }
}

//================================================================================
// FILE: ui/screens/marketing/MarketingScreen.kt
//================================================================================
package com.qpharma.ai.ui.screens.marketing

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.hilt.navigation.compose.hiltViewModel
import com.qpharma.ai.data.entity.MarketingCampaign
import com.qpharma.ai.data.entity.MarketingDesign
import com.qpharma.ai.ui.theme.QPharmaColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketingScreen(
    onNavigateBack: () -> Unit = {}
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("الحملات", "التصاميم", "الجدولة")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("التسويق الذكي", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = QPharmaColors.Background
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { /* Create campaign */ },
                containerColor = QPharmaColors.Primary,
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("حملة جديدة") }
            )
        },
        containerColor = QPharmaColors.Background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // AI Agent Status Card
            AIAgentStatusCard()

            // Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = QPharmaColors.Background,
                contentColor = QPharmaColors.Primary
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) }
                    )
                }
            }

            // Tab Content
            when (selectedTab) {
                0 -> CampaignsTab()
                1 -> DesignsTab()
                2 -> ScheduleTab()
            }
        }
    }
}

@Composable
private fun AIAgentStatusCard() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = QPharmaColors.Primary.copy(alpha = 0.08f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(QPharmaColors.Primary.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.SmartToy,
                    null,
                    tint = QPharmaColors.Primary,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "وكيل التسويق الذكي",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    "يقوم بتحليل المخزون واقتراح عروض على الأصناف الراكدة",
                    fontSize = 13.sp,
                    color = QPharmaColors.TextSecondary
                )
            }

            Switch(
                checked = true,
                onCheckedChange = {},
                colors = SwitchDefaults.colors(
                    checkedThumbColor = QPharmaColors.Primary,
                    checkedTrackColor = QPharmaColors.Primary.copy(alpha = 0.5f)
                )
            )
        }
    }
}

@Composable
private fun CampaignsTab() {
    val campaigns = listOf(
        CampaignItem("عروض الصيف", "promo", "نشطة", QPharmaColors.Success),
        CampaignItem("جمعة مباركة", "jumaa", "مجدولة", QPharmaColors.Warning),
        CampaignItem("تهنئة العيد", "holiday", "مسودة", QPharmaColors.TextSecondary)
    )

    LazyColumn(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(campaigns) { campaign ->
            CampaignCard(campaign = campaign)
        }
    }
}

@Composable
private fun CampaignCard(campaign: CampaignItem) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(QPharmaColors.Primary.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Campaign, null, tint = QPharmaColors.Primary)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(campaign.name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(
                    campaign.type,
                    fontSize = 12.sp,
                    color = QPharmaColors.TextSecondary
                )
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = campaign.statusColor.copy(alpha = 0.15f)
            ) {
                Text(
                    campaign.status,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    fontSize = 12.sp,
                    color = campaign.statusColor,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun DesignsTab() {
    val designTypes = listOf(
        DesignType("تهنئة الأعياد", Icons.Default.Celebration, Color(0xFFE91E63)),
        DesignType("جمعة مباركة", Icons.Default.Mosque, Color(0xFF4CAF50)),
        DesignType("عروض ترويجية", Icons.Default.LocalOffer, Color(0xFFFF9800)),
        DesignType("حملات توعية", Icons.Default.HealthAndSafety, Color(0xFF2196F3)),
        DesignType("تعزية ومواساة", Icons.Default.VolunteerActivism, Color(0xFF607D8B))
    )

    LazyColumn(modifier = Modifier.padding(16.dp)) {
        item {
            Text(
                "اختر نوع التصميم",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        items(designTypes) { type ->
            DesignTypeCard(type = type)
        }
    }
}

@Composable
private fun DesignTypeCard(type: DesignType) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clickable { /* Generate design */ },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(type.color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(type.icon, null, tint = type.color, modifier = Modifier.size(22.dp))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(type.name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(
                    "توليد AI مع هوية Q-Pharma",
                    fontSize = 12.sp,
                    color = QPharmaColors.TextSecondary
                )
            }

            Icon(Icons.Default.ChevronLeft, null, tint = QPharmaColors.TextSecondary)
        }
    }
}

@Composable
private fun ScheduleTab() {
    Column(modifier = Modifier.padding(16.dp)) {
        Text(
            "المنشورات المجدولة",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Weekly schedule
        val days = listOf("السبت", "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة")
        val scheduledDays = listOf(5) // Friday

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(days.size) { index ->
                val isScheduled = scheduledDays.contains(index)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isScheduled) QPharmaColors.Primary 
                                        else QPharmaColors.Surface
                    ),
                    modifier = Modifier.width(80.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            days[index],
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isScheduled) Color.White else QPharmaColors.TextPrimary
                        )
                        if (isScheduled) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Icon(
                                Icons.Default.Schedule,
                                null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Scheduled posts list
        ScheduledPostCard(
            title = "جمعة مباركة",
            time = "08:00 ص",
            status = "مجدول",
            channel = "واتساب"
        )
    }
}

@Composable
private fun ScheduledPostCard(
    title: String,
    time: String,
    status: String,
    channel: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(QPharmaColors.Warning.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Schedule, null, tint = QPharmaColors.Warning)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(
                    "$time | $channel",
                    fontSize = 12.sp,
                    color = QPharmaColors.TextSecondary
                )
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = QPharmaColors.Warning.copy(alpha = 0.15f)
            ) {
                Text(
                    status,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    fontSize = 12.sp,
                    color = QPharmaColors.Warning
                )
            }
        }
    }
}

// Data classes
data class CampaignItem(
    val name: String,
    val type: String,
    val status: String,
    val statusColor: Color
)

data class DesignType(
    val name: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color
)
