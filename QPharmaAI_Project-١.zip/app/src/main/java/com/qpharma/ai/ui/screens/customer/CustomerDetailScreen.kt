
//================================================================================
// FILE: ui/screens/customer/CustomerDetailScreen.kt
//================================================================================
package com.qpharma.ai.ui.screens.customer

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.qpharma.ai.data.entity.*
import com.qpharma.ai.ui.theme.QPharmaColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerDetailScreen(
    customerId: Long,
    viewModel: CustomerDetailViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit = {},
    onNewPrescription: () -> Unit = {},
    onViewInvoice: (Long) -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("المعلومات", "الفواتير", "الوصفات", "الربحية")

    LaunchedEffect(customerId) {
        viewModel.loadCustomer(customerId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ملف العميل", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { /* Edit */ }) {
                        Icon(Icons.Default.Edit, "تعديل")
                    }
                    IconButton(onClick = { /* More options */ }) {
                        Icon(Icons.Default.MoreVert, "المزيد")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = QPharmaColors.Background
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNewPrescription,
                containerColor = QPharmaColors.Primary,
                icon = { Icon(Icons.Default.Medication, null) },
                text = { Text("وصفة جديدة") }
            )
        },
        containerColor = QPharmaColors.Background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Profile Header
            item {
                CustomerProfileHeader(customer = uiState.customer)
            }

            // Quick Stats
            item {
                CustomerQuickStats(
                    totalVisits = uiState.totalVisits,
                    totalSpent = uiState.totalSpent,
                    loyaltyPoints = uiState.customer?.loyaltyPoints ?: 0,
                    remainingCredit = (uiState.customer?.creditLimit ?: 0.0) - uiState.totalDebt
                )
            }

            // Tabs
            item {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = QPharmaColors.Background,
                    contentColor = QPharmaColors.Primary
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = { Text(title, fontSize = 13.sp) }
                        )
                    }
                }
            }

            // Tab Content
            when (selectedTab) {
                0 -> { // Info
                    item {
                        CustomerInfoSection(customer = uiState.customer)
                    }
                }
                1 -> { // Invoices
                    items(uiState.invoices) { invoice ->
                        InvoiceMiniCard(invoice = invoice, onClick = { onViewInvoice(invoice.invoice.id) })
                    }
                }
                2 -> { // Prescriptions
                    items(uiState.prescriptions) { prescription ->
                        PrescriptionMiniCard(prescription = prescription)
                    }
                }
                3 -> { // Profitability
                    item {
                        ProfitabilitySection(
                            totalProfit = uiState.totalProfit,
                            profitHistory = uiState.profitHistory
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomerProfileHeader(customer: Patient?) {
    if (customer == null) return

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Avatar
        Box(
            modifier = Modifier
                .size(90.dp)
                .clip(CircleShape)
                .background(
                    androidx.compose.ui.graphics.Brush.linearGradient(
                        colors = listOf(QPharmaColors.Primary, QPharmaColors.Secondary)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                customer.name.take(2),
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 28.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            customer.name,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = QPharmaColors.TextPrimary
        )

        // Customer type badge
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = when (customer.customerType) {
                "vip" -> Color(0xFFFFD700).copy(alpha = 0.2f)
                "chronic" -> QPharmaColors.Error.copy(alpha = 0.15f)
                else -> QPharmaColors.Primary.copy(alpha = 0.1f)
            }
        ) {
            Text(
                when (customer.customerType) {
                    "vip" -> "عميل VIP"
                    "chronic" -> "عميل مزمن"
                    "supplies" -> "مستلزمات طبية"
                    else -> "عميل عادي"
                },
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                color = when (customer.customerType) {
                    "vip" -> Color(0xFFFFD700)
                    "chronic" -> QPharmaColors.Error
                    else -> QPharmaColors.Primary
                }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick actions
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            IconButton(
                onClick = { /* WhatsApp */ },
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(QPharmaColors.Success.copy(alpha = 0.15f))
            ) {
                Icon(Icons.Default.Chat, null, tint = QPharmaColors.Success)
            }
            IconButton(
                onClick = { /* Call */ },
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(QPharmaColors.Primary.copy(alpha = 0.15f))
            ) {
                Icon(Icons.Default.Phone, null, tint = QPharmaColors.Primary)
            }
            IconButton(
                onClick = { /* Share statement */ },
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(QPharmaColors.Info.copy(alpha = 0.15f))
            ) {
                Icon(Icons.Default.Share, null, tint = QPharmaColors.Info)
            }
        }
    }
}

@Composable
private fun CustomerQuickStats(
    totalVisits: Int,
    totalSpent: Double,
    loyaltyPoints: Int,
    remainingCredit: Double
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        QuickStatCard(
            title = "الزيارات",
            value = totalVisits.toString(),
            icon = Icons.Default.CalendarToday,
            color = QPharmaColors.Primary,
            modifier = Modifier.weight(1f)
        )
        QuickStatCard(
            title = "إجمالي الشراء",
            value = "${totalSpent.toInt()}",
            icon = Icons.Default.ShoppingCart,
            color = QPharmaColors.Success,
            modifier = Modifier.weight(1f)
        )
        QuickStatCard(
            title = "نقاط الولاء",
            value = loyaltyPoints.toString(),
            icon = Icons.Default.Star,
            color = Color(0xFFFFD700),
            modifier = Modifier.weight(1f)
        )
        QuickStatCard(
            title = "الرصيد المتاح",
            value = "${remainingCredit.toInt()}",
            icon = Icons.Default.CreditCard,
            color = QPharmaColors.Info,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun QuickStatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(90.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                value,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = QPharmaColors.TextPrimary
            )
            Text(
                title,
                fontSize = 10.sp,
                color = QPharmaColors.TextSecondary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
private fun CustomerInfoSection(customer: Patient?) {
    if (customer == null) return

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            InfoRow(icon = Icons.Default.Phone, label = "الهاتف", value = customer.phone ?: "—")
            InfoRow(icon = Icons.Default.Person, label = "الجنس", value = customer.gender ?: "—")
            InfoRow(icon = Icons.Default.Cake, label = "تاريخ الميلاد", value = customer.birthDate?.toString() ?: "—")
            InfoRow(icon = Icons.Default.MedicalServices, label = "الأمراض المزمنة", value = customer.chronicDiseases ?: "—")
            InfoRow(icon = Icons.Default.Warning, label = "الحساسية", value = customer.allergies ?: "—")
            InfoRow(icon = Icons.Default.LocalHospital, label = "الطبيب المعالج", value = customer.doctorName ?: "—")
            InfoRow(icon = Icons.Default.Notes, label = "ملاحظات", value = customer.notes ?: "—")
        }
    }
}

@Composable
private fun InfoRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = QPharmaColors.Primary, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(label, fontSize = 12.sp, color = QPharmaColors.TextSecondary)
            Text(value, fontSize = 14.sp, color = QPharmaColors.TextPrimary, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun InvoiceMiniCard(invoice: InvoiceWithCustomer, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Receipt, null, tint = QPharmaColors.Primary)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(invoice.invoice.invoiceNumber, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(invoice.invoice.createdAt.toString(), fontSize = 12.sp, color = QPharmaColors.TextSecondary)
            }
            Text(
                "${invoice.invoice.netAmount} ر.ي",
                fontWeight = FontWeight.Bold,
                color = QPharmaColors.Primary
            )
        }
    }
}

@Composable
private fun PrescriptionMiniCard(prescription: PrescriptionWithPatient) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Medication, null, tint = QPharmaColors.Secondary)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("وصفة #${prescription.prescription.id}", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(
                    "طريقة الإدخال: ${prescription.prescription.inputMethod}",
                    fontSize = 12.sp,
                    color = QPharmaColors.TextSecondary
                )
            }
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = when (prescription.prescription.status) {
                    "confirmed" -> QPharmaColors.Success.copy(alpha = 0.15f)
                    else -> QPharmaColors.Warning.copy(alpha = 0.15f)
                }
            ) {
                Text(
                    prescription.prescription.status,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    fontSize = 11.sp,
                    color = when (prescription.prescription.status) {
                        "confirmed" -> QPharmaColors.Success
                        else -> QPharmaColors.Warning
                    }
                )
            }
        }
    }
}

@Composable
private fun ProfitabilitySection(
    totalProfit: Double,
    profitHistory: List<ProfitEntry>
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                "الربحية التراكمية",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                "$totalProfit ر.ي",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = QPharmaColors.Success
            )
            Text(
                "إجمالي صافي الربح من هذا العميل",
                style = MaterialTheme.typography.bodySmall,
                color = QPharmaColors.TextSecondary
            )
        }
    }
}

// Placeholder data classes
class CustomerDetailViewModel : androidx.lifecycle.ViewModel() {
    private val _uiState = MutableStateFlow(CustomerDetailUiState())
    val uiState: StateFlow<CustomerDetailUiState> = _uiState.asStateFlow()

    fun loadCustomer(id: Long) {
        // Load from repository
    }
}

data class CustomerDetailUiState(
    val customer: Patient? = null,
    val totalVisits: Int = 0,
    val totalSpent: Double = 0.0,
    val totalDebt: Double = 0.0,
    val totalProfit: Double = 0.0,
    val invoices: List<InvoiceWithCustomer> = emptyList(),
    val prescriptions: List<PrescriptionWithPatient> = emptyList(),
    val profitHistory: List<ProfitEntry> = emptyList()
)

data class ProfitEntry(val date: String, val amount: Double)

@Composable
fun CustomerListScreen(
    onCustomerClick: (Long) -> Unit = {},
    onNavigateBack: () -> Unit = {}
) {
    // Implementation placeholder
}
