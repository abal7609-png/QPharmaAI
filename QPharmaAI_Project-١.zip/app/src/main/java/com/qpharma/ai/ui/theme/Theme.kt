
//================================================================================
// FILE: ui/theme/QPharmaColors.kt
//================================================================================
package com.qpharma.ai.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Q-Pharma AI Color System
 * Primary: Teal (#0f766e) | Secondary: Teal Light (#0d9488)
 * Background: Mint Light for light mode, Dark Slate for dark mode
 */
object QPharmaColors {
    // Primary palette
    val Primary = Color(0xFF0f766e)
    val PrimaryDark = Color(0xFF134e4a)
    val Secondary = Color(0xFF0d9488)
    val Accent = Color(0xFF2dd4bf)

    // Semantic colors
    val Success = Color(0xFF22c55e)
    val Warning = Color(0xFFf59e0b)
    val Error = Color(0xFFef4444)
    val Info = Color(0xFF3b82f6)

    // Background colors
    val Background = Color(0xFF0f172a)      // Dark mode default
    val Surface = Color(0xFF1e293b)
    val SurfaceVariant = Color(0xFF334155)

    // Text colors
    val TextPrimary = Color(0xFFf1f5f9)
    val TextSecondary = Color(0xFF94a3b8)
    val TextDisabled = Color(0xFF64748b)

    // Light mode variants (auto-switched)
    val BackgroundLight = Color(0xFFf0fdf4)   // Mint light
    val SurfaceLight = Color(0xFFFFFFFF)
    val SurfaceVariantLight = Color(0xFFf1f5f9)
    val TextPrimaryLight = Color(0xFF0f172a)
    val TextSecondaryLight = Color(0xFF475569)
}

//================================================================================
// FILE: ui/theme/Theme.kt
//================================================================================
package com.qpharma.ai.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = QPharmaColors.Primary,
    secondary = QPharmaColors.Secondary,
    tertiary = QPharmaColors.Accent,
    background = QPharmaColors.Background,
    surface = QPharmaColors.Surface,
    surfaceVariant = QPharmaColors.SurfaceVariant,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = QPharmaColors.TextPrimary,
    onSurface = QPharmaColors.TextPrimary,
    error = QPharmaColors.Error,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = QPharmaColors.Primary,
    secondary = QPharmaColors.Secondary,
    tertiary = QPharmaColors.Accent,
    background = QPharmaColors.BackgroundLight,
    surface = QPharmaColors.SurfaceLight,
    surfaceVariant = QPharmaColors.SurfaceVariantLight,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = QPharmaColors.TextPrimaryLight,
    onSurface = QPharmaColors.TextPrimaryLight,
    error = QPharmaColors.Error,
    onError = Color.White
)

@Composable
fun QPharmaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = QPharmaTypography,
        content = content
    )
}

//================================================================================
// FILE: ui/theme/Type.kt
//================================================================================
package com.qpharma.ai.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val QPharmaTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 57.sp,
        lineHeight = 64.sp
    ),
    headlineLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp,
        lineHeight = 40.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp
    )
)

//================================================================================
// FILE: worker/ReminderScheduler.kt
//================================================================================
package com.qpharma.ai.worker

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.qpharma.ai.data.entity.MedicationReminder
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Reminder Scheduler using AlarmManager + WorkManager
 * Schedules medication refill reminders before depletion
 */
@Singleton
class ReminderScheduler @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    /**
     * Schedule a reminder alarm using AlarmManager
     * This ensures the reminder fires even if the app is killed
     */
    fun scheduleReminder(reminder: MedicationReminder) {
        val intent = Intent(context, ReminderBroadcastReceiver::class.java).apply {
            action = "com.qpharma.ai.REMINDER"
            putExtra("reminder_id", reminder.id)
            putExtra("drug_name", reminder.drugName)
            putExtra("customer_id", reminder.customerId)
            putExtra("message", reminder.message)
            putExtra("channel", reminder.channel)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            reminder.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Parse reminder time
        val timeParts = reminder.reminderTime.split(":")
        val hour = timeParts[0].toInt()
        val minute = timeParts[1].toInt()

        val calendar = Calendar.getInstance().apply {
            time = reminder.reminderDate
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
        }

        // Use exact alarm for critical medication reminders
        alarmManager.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            calendar.timeInMillis,
            pendingIntent
        )
    }

    fun cancelReminder(reminderId: Long) {
        val intent = Intent(context, ReminderBroadcastReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            reminderId.toInt(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        pendingIntent?.let { alarmManager.cancel(it) }
    }
}

//================================================================================
// FILE: worker/ReminderBroadcastReceiver.kt
//================================================================================
package com.qpharma.ai.worker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.qpharma.ai.data.dao.MedicationReminderDao
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * BroadcastReceiver for medication reminders
 * Triggers notification and optionally sends WhatsApp/SMS
 */
@AndroidEntryPoint
class ReminderBroadcastReceiver : BroadcastReceiver() {

    @Inject
    lateinit var reminderDao: MedicationReminderDao

    @Inject
    lateinit var notificationManager: QPharmaNotificationManager

    @Inject
    lateinit var messageSender: MessageSender

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getLongExtra("reminder_id", -1)
        val drugName = intent.getStringExtra("drug_name") ?: return
        val customerId = intent.getLongExtra("customer_id", -1)
        val message = intent.getStringExtra("message") ?: ""
        val channel = intent.getStringExtra("channel") ?: "notification"

        CoroutineScope(Dispatchers.IO).launch {
            // Show local notification
            notificationManager.showMedicationReminder(
                reminderId = reminderId,
                drugName = drugName,
                message = message
            )

            // Send WhatsApp/SMS if configured
            if (channel == "whatsapp" || channel == "sms") {
                messageSender.sendReminder(customerId, message, channel)
            }

            // Update reminder status
            reminderDao.updateStatus(reminderId, "sent")
        }
    }
}

//================================================================================
// FILE: worker/MarketingSchedulerWorker.kt
//================================================================================
package com.qpharma.ai.worker

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.qpharma.ai.data.dao.MarketingDao
import com.qpharma.ai.data.entity.MarketingDesign
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * WorkManager worker for scheduled marketing campaigns
 * Handles: Jumaa Mubarak posts, holiday greetings, promotional campaigns
 */
@HiltWorker
class MarketingSchedulerWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val marketingDao: MarketingDao,
    private val designEngine: AIDesignEngine
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val currentDay = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        val currentDate = Calendar.getInstance()

        // Check for scheduled designs
        val pendingDesigns = marketingDao.getPendingDesignsForDate(currentDate.time)

        pendingDesigns.forEach { design ->
            // Publish the design
            publishDesign(design)
            marketingDao.updatePublishStatus(design.id, "published", currentDate.time)
        }

        // Auto-generate Jumaa Mubarak if it's Friday and no design scheduled
        if (currentDay == Calendar.FRIDAY) {
            generateAndPublishJumaaPost()
        }

        return Result.success()
    }

    private suspend fun publishDesign(design: MarketingDesign) {
        // Implementation: Share to WhatsApp Business, social media
        // Uses AI Design Engine with brand kit
    }

    private suspend fun generateAndPublishJumaaPost() {
        val design = designEngine.generateDesign(
            type = "jumaa",
            brandKit = getBrandKit()
        )
        // Publish automatically
    }

    private fun getBrandKit() = BrandKit(
        primaryColor = "#0f766e",
        logoPath = "brand/logo.png",
        fontFamily = "Cairo"
    )

    companion object {
        fun schedulePeriodic(context: Context) {
            val workRequest = PeriodicWorkRequestBuilder<MarketingSchedulerWorker>(
                15, TimeUnit.MINUTES
            ).setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build()
            ).build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "marketing_scheduler",
                ExistingPeriodicWorkPolicy.KEEP,
                workRequest
            )
        }
    }
}

//================================================================================
// FILE: worker/SyncWorker.kt
//================================================================================
package com.qpharma.ai.worker

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.qpharma.ai.data.database.QPharmaDatabase
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

/**
 * Background sync worker for cloud backup
 * Runs when device is charging and connected to WiFi
 */
@HiltWorker
class SyncWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val database: QPharmaDatabase,
    private val cloudSyncManager: CloudSyncManager
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            // Get all pending sync records
            val pendingRecords = database.patientDao().getPendingSyncRecords()

            pendingRecords.forEach { record ->
                cloudSyncManager.syncRecord(record)
                database.patientDao().markAsSynced(record.id)
            }

            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        fun scheduleSync(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.UNMETERED)
                .setRequiresCharging(true)
                .build()

            val syncWork = PeriodicWorkRequestBuilder<SyncWorker>(
                1, TimeUnit.HOURS
            ).setConstraints(constraints).build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "cloud_sync",
                ExistingPeriodicWorkPolicy.KEEP,
                syncWork
            )
        }
    }
}

// Placeholder interfaces for compilation
data class BrandKit(val primaryColor: String, val logoPath: String, val fontFamily: String)
interface AIDesignEngine {
    suspend fun generateDesign(type: String, brandKit: BrandKit): MarketingDesign
}
interface CloudSyncManager {
    suspend fun syncRecord(record: Any)
}
interface QPharmaNotificationManager {
    fun showMedicationReminder(reminderId: Long, drugName: String, message: String)
}
interface MessageSender {
    suspend fun sendReminder(customerId: Long, message: String, channel: String)
}
