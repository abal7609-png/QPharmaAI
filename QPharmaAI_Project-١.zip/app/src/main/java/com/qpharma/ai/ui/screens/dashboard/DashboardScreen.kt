
//================================================================================
// FILE: ui/screens/dashboard/DashboardScreen.kt
//================================================================================
package com.qpharma.ai.ui.screens.dashboard

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.qpharma.ai.data.entity.*
import com.qpharma.ai.ui.theme.QPharmaColors
import com.qpharma.ai.ui.viewmodel.*
import java.text.NumberFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel = hiltViewModel(),
    onNavigateToPatient: (Long) -> Unit = {},
    onNavigateToProduct: (Long) -> Unit = {},
    onNavigateToPrescription: () -> Unit = {},
    onNavigateToSales: () -> Unit = {},
    onNavigateToDocuments: () -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()

    Scaffold(
        topBar = {
            LargeTopAppBar(
                title = {
                    Column {
                        Text(
                            "Q-Pharma AI",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = QPharmaColors.Primary
                        )
                        Text(
                            "لوحة التحكم الذكية",
                            style = MaterialTheme.typography.bodyMedium,
                            color = QPharmaColors.TextSecondary
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.refreshDashboard() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = QPharmaColors.Primary)
                    }
                    IconButton(onClick = { /* Open notifications */ }) {
                        BadgedBox(
                            badge = {
                                if (uiState.alerts.isNotEmpty()) {
                                    Badge { Text(uiState.alerts.size.toString()) }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Notifications, contentDescription = "تنبيهات", tint = QPharmaColors.Primary)
                        }
                    }
                },
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = QPharmaColors.Background,
                    scrolledContainerColor = QPharmaColors.Background
                ),
                scrollBehavior = scrollBehavior
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNavigateToPrescription,
                containerColor = QPharmaColors.Primary,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("وصفة جديدة") }
            )
        },
        containerColor = QPharmaColors.Background
    ) { padding ->

        if (uiState.isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = QPharmaColors.Primary)
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ===== STATS CARDS ROW =====
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    item {
                        StatCard(
                            title = "مبيعات اليوم",
                            value = formatCurrency(uiState.todayStats.totalSales),
                            icon = Icons.Default.AttachMoney,
                            color = QPharmaColors.Success,
                            subtitle = "${uiState.todayStats.invoiceCount} فاتورة"
                        )
                    }
                    item {
                        StatCard(
                            title = "تذكيرات اليوم",
                            value = uiState.todayStats.pendingReminders.toString(),
                            icon = Icons.Default.Alarm,
                            color = QPharmaColors.Warning,
                            subtitle = "منبهات نشطة"
                        )
                    }
                    item {
                        StatCard(
                            title = "الديون المستحقة",
                            value = formatCurrency(uiState.todayStats.totalDebt),
                            icon = Icons.Default.AccountBalanceWallet,
                            color = QPharmaColors.Error,
                            subtitle = "ديون العملاء"
                        )
                    }
                }
            }

            // ===== CRITICAL ALERTS =====
            if (uiState.alerts.isNotEmpty()) {
                item {
                    Text(
                        "تنبيهات حرجة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = QPharmaColors.TextPrimary,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                items(uiState.alerts.take(5), key = { it.entityId }) { alert ->
                    AlertCard(
                        alert = alert,
                        onDismiss = { viewModel.dismissAlert(alert.entityId) },
                        onAction = { viewModel.onAlertAction(alert) }
                    )
                }
            }

            // ===== EXPECTED VISITS TODAY =====
            item {
                SectionHeader(
                    title = "زيارات متوقعة اليوم",
                    count = uiState.expectedVisits.size,
                    icon = Icons.Default.CalendarToday
                )
            }
            items(uiState.expectedVisits) { patient ->
                PatientVisitCard(
                    patient = patient,
                    onClick = { onNavigateToPatient(patient.id) }
                )
            }

            // ===== NEAR DEPLETION PATIENTS =====
            item {
                SectionHeader(
                    title = "أدوية على وشك الانتهاء",
                    count = uiState.nearDepletionPatients.size,
                    icon = Icons.Default.Medication
                )
            }
            items(uiState.nearDepletionPatients) { patient ->
                PatientDepletionCard(
                    patient = patient,
                    onClick = { onNavigateToPatient(patient.id) }
                )
            }

            // ===== LOW STOCK ITEMS =====
            if (uiState.lowStockItems.isNotEmpty()) {
                item {
                    SectionHeader(
                        title = "نقص المخزون",
                        count = uiState.lowStockItems.size,
                        icon = Icons.Default.Warning
                    )
                }
                items(uiState.lowStockItems.take(5)) { product ->
                    LowStockCard(
                        product = product,
                        onClick = { onNavigateToProduct(product.id) }
                    )
                }
            }

            // ===== NEAR EXPIRY ITEMS =====
            if (uiState.nearExpiryItems.isNotEmpty()) {
                item {
                    SectionHeader(
                        title = "اقتراب انتهاء الصلاحية",
                        count = uiState.nearExpiryItems.size,
                        icon = Icons.Default.Timer
                    )
                }
                items(uiState.nearExpiryItems.take(5)) { product ->
                    ExpiryCard(
                        product = product,
                        onClick = { onNavigateToProduct(product.id) }
                    )
                }
            }

            // Bottom spacing
            item { Spacer(modifier = Modifier.height(80.dp)) }
        }
    }
}

// ===== STAT CARD COMPONENT =====
@Composable
private fun StatCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    subtitle: String
) {
    Card(
        modifier = Modifier
            .width(160.dp)
            .height(110.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
                }
            }

            Column {
                Text(
                    value,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = QPharmaColors.TextPrimary,
                    fontSize = 20.sp
                )
                Text(
                    title,
                    style = MaterialTheme.typography.bodySmall,
                    color = QPharmaColors.TextSecondary,
                    fontSize = 11.sp
                )
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = color,
                    fontSize = 10.sp
                )
            }
        }
    }
}

// ===== ALERT CARD COMPONENT =====
@Composable
private fun AlertCard(
    alert: DashboardAlert,
    onDismiss: () -> Unit,
    onAction: () -> Unit
) {
    val (bgColor, icon, iconColor) = when (alert.severity) {
        AlertSeverity.CRITICAL -> Triple(QPharmaColors.Error.copy(alpha = 0.1f), Icons.Default.Error, QPharmaColors.Error)
        AlertSeverity.HIGH -> Triple(QPharmaColors.Warning.copy(alpha = 0.1f), Icons.Default.Warning, QPharmaColors.Warning)
        AlertSeverity.MEDIUM -> Triple(QPharmaColors.Info.copy(alpha = 0.1f), Icons.Default.Info, QPharmaColors.Info)
        AlertSeverity.LOW -> Triple(QPharmaColors.Success.copy(alpha = 0.1f), Icons.Default.CheckCircle, QPharmaColors.Success)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onAction() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    alert.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = QPharmaColors.TextPrimary
                )
                Text(
                    alert.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = QPharmaColors.TextSecondary
                )
            }
            IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = QPharmaColors.TextSecondary)
            }
        }
    }
}

// ===== PATIENT VISIT CARD =====
@Composable
private fun PatientVisitCard(
    patient: Patient,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar with initials
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(QPharmaColors.Primary, QPharmaColors.Secondary)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    patient.name.take(2),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    patient.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = QPharmaColors.TextPrimary
                )
                Text(
                    "${patient.phone ?: ""} | ${patient.customerType}",
                    style = MaterialTheme.typography.bodySmall,
                    color = QPharmaColors.TextSecondary
                )
                if (!patient.chronicDiseases.isNullOrBlank()) {
                    Text(
                        "الأمراض المزمنة: ${patient.chronicDiseases}",
                        style = MaterialTheme.typography.bodySmall,
                        color = QPharmaColors.Error,
                        maxLines = 1
                    )
                }
            }

            // Quick action buttons
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = { /* Open WhatsApp */ },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        Icons.Default.Chat,
                        contentDescription = "واتساب",
                        tint = QPharmaColors.Success,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

// ===== PATIENT DEPLETION CARD =====
@Composable
private fun PatientDepletionCard(
    patient: Patient,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = QPharmaColors.Warning.copy(alpha = 0.08f)
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = QPharmaColors.Warning.copy(alpha = 0.3f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(QPharmaColors.Warning.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Medication,
                    contentDescription = null,
                    tint = QPharmaColors.Warning,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    patient.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = QPharmaColors.TextPrimary
                )
                Text(
                    "أدوية على وشك الانتهاء خلال 3 أيام",
                    style = MaterialTheme.typography.bodySmall,
                    color = QPharmaColors.Warning
                )
            }

            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = QPharmaColors.Warning),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(36.dp)
            ) {
                Text("إعادة صرف", fontSize = 12.sp)
            }
        }
    }
}

// ===== LOW STOCK CARD =====
@Composable
private fun LowStockCard(
    product: Product,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(QPharmaColors.Error.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Inventory,
                    contentDescription = null,
                    tint = QPharmaColors.Error,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    product.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    "المخزون: ${product.quantity} | الحد الأدنى: ${product.minStock}",
                    style = MaterialTheme.typography.bodySmall,
                    color = QPharmaColors.Error
                )
            }

            // Stock progress indicator
            val stockRatio = (product.quantity.toFloat() / product.minStock).coerceIn(0f, 1f)
            Box(
                modifier = Modifier
                    .width(60.dp)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(QPharmaColors.SurfaceVariant)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(stockRatio)
                        .background(
                            when {
                                stockRatio < 0.3f -> QPharmaColors.Error
                                stockRatio < 0.7f -> QPharmaColors.Warning
                                else -> QPharmaColors.Success
                            }
                        )
                )
            }
        }
    }
}

// ===== EXPIRY CARD =====
@Composable
private fun ExpiryCard(
    product: Product,
    onClick: () -> Unit
) {
    val daysUntilExpiry = product.expiryDate?.let { expiry ->
        val diff = expiry.time - System.currentTimeMillis()
        (diff / (1000 * 60 * 60 * 24)).toInt()
    } ?: 0

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(QPharmaColors.Info.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Timer,
                    contentDescription = null,
                    tint = QPharmaColors.Info,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    product.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    "ينتهي خلال $daysUntilExpiry يوم",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (daysUntilExpiry <= 7) QPharmaColors.Error else QPharmaColors.Warning
                )
            }
        }
    }
}

// ===== SECTION HEADER =====
@Composable
private fun SectionHeader(
    title: String,
    count: Int,
    icon: ImageVector
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                icon,
                contentDescription = null,
                tint = QPharmaColors.Primary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = QPharmaColors.TextPrimary
            )
        }

        if (count > 0) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = QPharmaColors.Primary.copy(alpha = 0.1f)
            ) {
                Text(
                    count.toString(),
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = QPharmaColors.Primary
                )
            }
        }
    }
}

// ===== UTILITY FUNCTIONS =====
private fun formatCurrency(amount: Double): String {
    return NumberFormat.getCurrencyInstance(Locale("ar", "SA")).format(amount)
}
