
//================================================================================
// FILE: ui/screens/sales/SalesScreen.kt
//================================================================================
package com.qpharma.ai.ui.screens.sales

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.hilt.navigation.compose.hiltViewModel
import com.qpharma.ai.data.entity.*
import com.qpharma.ai.ui.theme.QPharmaColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesScreen(
    viewModel: SalesViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit = {},
    onInvoiceClick: (Long) -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()
    var showNewInvoice by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("نقاط البيع", fontWeight = FontWeight.Bold)
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { /* Search */ }) {
                        Icon(Icons.Default.Search, "بحث")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = QPharmaColors.Background
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showNewInvoice = true },
                containerColor = QPharmaColors.Primary,
                icon = { Icon(Icons.Default.PointOfSale, null) },
                text = { Text("فاتورة جديدة") }
            )
        },
        containerColor = QPharmaColors.Background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // Cashbox selector
            CashboxSelector(
                cashboxes = uiState.cashboxes,
                selectedCashbox = uiState.selectedCashbox,
                onSelect = { viewModel.selectCashbox(it) }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Recent invoices
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "الفواتير الأخيرة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = QPharmaColors.TextPrimary
                        )
                        TextButton(onClick = { /* View all */ }) {
                            Text("عرض الكل", color = QPharmaColors.Primary)
                        }
                    }
                }

                items(uiState.recentInvoices) { invoice ->
                    InvoiceCard(
                        invoice = invoice,
                        onClick = { onInvoiceClick(invoice.id) }
                    )
                }
            }
        }
    }

    if (showNewInvoice) {
        NewInvoiceDialog(
            products = uiState.products,
            customers = uiState.customers,
            selectedCashbox = uiState.selectedCashbox,
            onDismiss = { showNewInvoice = false },
            onCreateInvoice = { invoice, items ->
                viewModel.createInvoice(invoice, items)
                showNewInvoice = false
            }
        )
    }
}

@Composable
private fun CashboxSelector(
    cashboxes: List<Cashbox>,
    selectedCashbox: Cashbox?,
    onSelect: (Cashbox) -> Unit
) {
    Text(
        "الصندوق المختار",
        style = MaterialTheme.typography.bodyMedium,
        color = QPharmaColors.TextSecondary,
        modifier = Modifier.padding(bottom = 8.dp)
    )

    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(cashboxes) { cashbox ->
            val isSelected = selectedCashbox?.id == cashbox.id
            Card(
                modifier = Modifier
                    .width(140.dp)
                    .clickable { onSelect(cashbox) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) QPharmaColors.Primary 
                                     else QPharmaColors.Surface
                ),
                border = if (isSelected) null else androidx.compose.foundation.BorderStroke(
                    1.dp, QPharmaColors.SurfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Icon(
                        Icons.Default.AccountBalanceWallet,
                        null,
                        tint = if (isSelected) Color.White else QPharmaColors.Primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        cashbox.name,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isSelected) Color.White else QPharmaColors.TextPrimary
                    )
                    Text(
                        "${cashbox.balance} ${cashbox.currency}",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isSelected) Color.White.copy(alpha = 0.8f) 
                                else QPharmaColors.TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun InvoiceCard(
    invoice: InvoiceWithCustomer,
    onClick: () -> Unit
) {
    val statusColor = when (invoice.invoice.paymentStatus) {
        "paid" -> QPharmaColors.Success
        "partial" -> QPharmaColors.Warning
        else -> QPharmaColors.Error
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(statusColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Receipt,
                    null,
                    tint = statusColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    invoice.invoice.invoiceNumber,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    invoice.customerName ?: "عميل نقدي",
                    style = MaterialTheme.typography.bodySmall,
                    color = QPharmaColors.TextSecondary
                )
                Text(
                    when (invoice.invoice.paymentStatus) {
                        "paid" -> "مدفوع"
                        "partial" -> "مدفوع جزئياً"
                        else -> "غير مدفوع"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = statusColor
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    "${invoice.invoice.netAmount} ر.ي",
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = QPharmaColors.TextPrimary
                )
                if (invoice.invoice.remaining > 0) {
                    Text(
                        "متبقي: ${invoice.invoice.remaining}",
                        style = MaterialTheme.typography.bodySmall,
                        color = QPharmaColors.Error
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NewInvoiceDialog(
    products: List<ProductWithCustomerPrice>,
    customers: List<Patient>,
    selectedCashbox: Cashbox?,
    onDismiss: () -> Unit,
    onCreateInvoice: (Invoice, List<InvoiceItem>) -> Unit
) {
    var selectedCustomer by remember { mutableStateOf<Patient?>(null) }
    var cartItems by remember { mutableStateOf(listOf<CartItem>()) }
    var showProductSelector by remember { mutableStateOf(false) }
    var discountPercent by remember { mutableStateOf(0.0) }

    val subtotal = cartItems.sumOf { it.totalPrice }
    val discountAmount = subtotal * (discountPercent / 100)
    val netTotal = subtotal - discountAmount

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = QPharmaColors.Background)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "فاتورة جديدة",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, null)
                    }
                }

                // Customer selector
                ExposedDropdownMenuBox(
                    expanded = false,
                    onExpandedChange = {}
                ) {
                    OutlinedTextField(
                        value = selectedCustomer?.name ?: "اختر العميل (اختياري)",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("العميل") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = false) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Add product button
                OutlinedButton(
                    onClick = { showProductSelector = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("إضافة صنف")
                }

                // Cart items
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(cartItems) { item ->
                        CartItemCard(
                            item = item,
                            onUpdateQty = { newQty ->
                                cartItems = cartItems.map {
                                    if (it.product.id == item.product.id) 
                                        it.copy(quantity = newQty, totalPrice = newQty * it.unitPrice)
                                    else it
                                }
                            },
                            onRemove = {
                                cartItems = cartItems.filter { it.product.id != item.product.id }
                            }
                        )
                    }
                }

                // Totals
                Divider(modifier = Modifier.padding(vertical = 8.dp), color = QPharmaColors.SurfaceVariant)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("المجموع", color = QPharmaColors.TextSecondary)
                    Text("$subtotal ر.ي", fontWeight = FontWeight.SemiBold)
                }

                if (discountPercent > 0) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("الخصم ($discountPercent%)", color = QPharmaColors.Success)
                        Text("-$discountAmount ر.ي", color = QPharmaColors.Success)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "الصافي",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "$netTotal ر.ي",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = QPharmaColors.Primary
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Create invoice button
                Button(
                    onClick = {
                        val invoice = Invoice(
                            invoiceNumber = generateInvoiceNumber(),
                            customerId = selectedCustomer?.id ?: 0,
                            totalAmount = subtotal,
                            discountAmount = discountAmount,
                            netAmount = netTotal,
                            paidAmount = netTotal,
                            remaining = 0.0,
                            paymentStatus = "paid",
                            cashboxId = selectedCashbox?.id
                        )
                        val items = cartItems.map {
                            InvoiceItem(
                                invoiceId = 0,
                                productId = it.product.id,
                                quantity = it.quantity,
                                unitPrice = it.unitPrice,
                                totalPrice = it.totalPrice,
                                profitPerUnit = it.unitPrice - (it.product.purchasePrice),
                                totalProfit = (it.unitPrice - it.product.purchasePrice) * it.quantity
                            )
                        }
                        onCreateInvoice(invoice, items)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    enabled = cartItems.isNotEmpty() && selectedCashbox != null
                ) {
                    Text("إنشاء الفاتورة", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
private fun CartItemCard(
    item: CartItem,
    onUpdateQty: (Int) -> Unit,
    onRemove: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    item.product.name,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
                Text(
                    "${item.unitPrice} ر.ي / وحدة",
                    style = MaterialTheme.typography.bodySmall,
                    color = QPharmaColors.TextSecondary
                )
            }

            // Qty controls
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { if (item.quantity > 1) onUpdateQty(item.quantity - 1) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.Remove, null, tint = QPharmaColors.Primary)
                }
                Text(
                    item.quantity.toString(),
                    modifier = Modifier.padding(horizontal = 8.dp),
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = { onUpdateQty(item.quantity + 1) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.Add, null, tint = QPharmaColors.Primary)
                }
            }

            Text(
                "${item.totalPrice} ر.ي",
                fontWeight = FontWeight.Bold,
                color = QPharmaColors.Primary,
                modifier = Modifier.padding(start = 8.dp)
            )

            IconButton(onClick = onRemove, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Delete, null, tint = QPharmaColors.Error)
            }
        }
    }
}

private fun generateInvoiceNumber(): String {
    val date = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.getDefault())
        .format(java.util.Date())
    val random = (1000..9999).random()
    return "INV-$date-$random"
}

data class CartItem(
    val product: Product,
    val quantity: Int,
    val unitPrice: Double,
    val totalPrice: Double
)

// Placeholder ViewModel
data class SalesUiState(
    val cashboxes: List<Cashbox> = emptyList(),
    val selectedCashbox: Cashbox? = null,
    val recentInvoices: List<InvoiceWithCustomer> = emptyList(),
    val products: List<ProductWithCustomerPrice> = emptyList(),
    val customers: List<Patient> = emptyList()
)

class SalesViewModel : androidx.lifecycle.ViewModel() {
    private val _uiState = MutableStateFlow(SalesUiState())
    val uiState: StateFlow<SalesUiState> = _uiState.asStateFlow()

    fun selectCashbox(cashbox: Cashbox) {
        _uiState.update { it.copy(selectedCashbox = cashbox) }
    }

    fun createInvoice(invoice: Invoice, items: List<InvoiceItem>) {
        // Implementation
    }
}

@Composable
fun InvoiceDetailScreen(invoiceId: Long, onNavigateBack: () -> Unit) {
    // Implementation placeholder
}
