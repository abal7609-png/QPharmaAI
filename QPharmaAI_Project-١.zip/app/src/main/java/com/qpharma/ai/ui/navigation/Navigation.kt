
//================================================================================
// FILE: ui/navigation/QPharmaNavigation.kt
//================================================================================
package com.qpharma.ai.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.qpharma.ai.ui.screens.dashboard.DashboardScreen
import com.qpharma.ai.ui.screens.prescription.PrescriptionScreen
import com.qpharma.ai.ui.screens.customer.CustomerDetailScreen
import com.qpharma.ai.ui.screens.customer.CustomerListScreen
import com.qpharma.ai.ui.screens.sales.SalesScreen
import com.qpharma.ai.ui.screens.sales.InvoiceDetailScreen
import com.qpharma.ai.ui.screens.document.DocumentScreen
import com.qpharma.ai.ui.screens.marketing.MarketingScreen
import com.qpharma.ai.ui.screens.supplier.SupplierScreen
import com.qpharma.ai.ui.screens.settings.SettingsScreen
import com.qpharma.ai.ui.screens.vision.VisionChatScreen

/**
 * Navigation Routes for Q-Pharma AI
 * All screens accessible within max 3 clicks from Dashboard
 */
sealed class Screen(val route: String) {
    object Dashboard : Screen("dashboard")
    object Prescription : Screen("prescription?customerId={customerId}") {
        fun createRoute(customerId: Long? = null) = 
            "prescription?customerId=$customerId"
    }
    object CustomerList : Screen("customers")
    object CustomerDetail : Screen("customer/{customerId}") {
        fun createRoute(customerId: Long) = "customer/$customerId"
    }
    object Sales : Screen("sales")
    object InvoiceDetail : Screen("invoice/{invoiceId}") {
        fun createRoute(invoiceId: Long) = "invoice/$invoiceId"
    }
    object Documents : Screen("documents")
    object Marketing : Screen("marketing")
    object Suppliers : Screen("suppliers")
    object Settings : Screen("settings")
    object VisionChat : Screen("vision_chat?screenType={screenType}") {
        fun createRoute(screenType: String = "dashboard") = "vision_chat?screenType=$screenType"
    }
}

@Composable
fun QPharmaNavHost(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screen.Dashboard.route
    ) {
        // Dashboard
        composable(Screen.Dashboard.route) {
            DashboardScreen(
                onNavigateToPatient = { id ->
                    navController.navigate(Screen.CustomerDetail.createRoute(id))
                },
                onNavigateToProduct = { id ->
                    // Navigate to product detail
                },
                onNavigateToPrescription = {
                    navController.navigate(Screen.Prescription.createRoute())
                },
                onNavigateToSales = {
                    navController.navigate(Screen.Sales.route)
                },
                onNavigateToDocuments = {
                    navController.navigate(Screen.Documents.route)
                }
            )
        }

        // Prescription with optional customerId
        composable(
            route = "prescription?customerId={customerId}",
            arguments = listOf(
                navArgument("customerId") {
                    type = NavType.LongType
                    defaultValue = -1L
                }
            )
        ) { backStackEntry ->
            val customerId = backStackEntry.arguments?.getLong("customerId")
            PrescriptionScreen(
                customerId = customerId?.takeIf { it != -1L },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // Customer List
        composable(Screen.CustomerList.route) {
            CustomerListScreen(
                onCustomerClick = { id ->
                    navController.navigate(Screen.CustomerDetail.createRoute(id))
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // Customer Detail
        composable(
            route = Screen.CustomerDetail.route,
            arguments = listOf(navArgument("customerId") { type = NavType.LongType })
        ) { backStackEntry ->
            val customerId = backStackEntry.arguments?.getLong("customerId") ?: 0L
            CustomerDetailScreen(
                customerId = customerId,
                onNavigateBack = { navController.popBackStack() },
                onNewPrescription = {
                    navController.navigate(Screen.Prescription.createRoute(customerId))
                },
                onViewInvoice = { invoiceId ->
                    navController.navigate(Screen.InvoiceDetail.createRoute(invoiceId))
                }
            )
        }

        // Sales / POS
        composable(Screen.Sales.route) {
            SalesScreen(
                onNavigateBack = { navController.popBackStack() },
                onInvoiceClick = { id ->
                    navController.navigate(Screen.InvoiceDetail.createRoute(id))
                }
            )
        }

        // Invoice Detail
        composable(
            route = Screen.InvoiceDetail.route,
            arguments = listOf(navArgument("invoiceId") { type = NavType.LongType })
        ) { backStackEntry ->
            val invoiceId = backStackEntry.arguments?.getLong("invoiceId") ?: 0L
            InvoiceDetailScreen(
                invoiceId = invoiceId,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // Documents
        composable(Screen.Documents.route) {
            DocumentScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // Marketing
        composable(Screen.Marketing.route) {
            MarketingScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // Suppliers
        composable(Screen.Suppliers.route) {
            SupplierScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // Settings
        composable(Screen.Settings.route) {
            SettingsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // Vision Chat (AI Assistant overlay)
        composable(
            route = "vision_chat?screenType={screenType}",
            arguments = listOf(
                navArgument("screenType") {
                    type = NavType.StringType
                    defaultValue = "dashboard"
                }
            )
        ) { backStackEntry ->
            val screenType = backStackEntry.arguments?.getString("screenType") ?: "dashboard"
            VisionChatScreen(
                screenType = screenType,
                onDismiss = { navController.popBackStack() }
            )
        }
    }
}

//================================================================================
// FILE: MainActivity.kt
//================================================================================
package com.qpharma.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.qpharma.ai.ui.navigation.QPharmaNavHost
import com.qpharma.ai.ui.theme.QPharmaTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            QPharmaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    QPharmaNavHost(navController = navController)
                }
            }
        }
    }
}

//================================================================================
// FILE: QPharmaApplication.kt
//================================================================================
package com.qpharma.ai

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.qpharma.ai.worker.MarketingSchedulerWorker
import com.qpharma.ai.worker.SyncWorker
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class QPharmaApplication : Application(), Configuration.Provider {

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    override fun onCreate() {
        super.onCreate()

        // Schedule background workers on app start
        MarketingSchedulerWorker.schedulePeriodic(this)
        SyncWorker.scheduleSync(this)
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()
}
