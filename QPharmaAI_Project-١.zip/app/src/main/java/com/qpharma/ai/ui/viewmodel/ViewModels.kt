
//================================================================================
// FILE: ui/viewmodel/DashboardViewModel.kt
//================================================================================
package com.qpharma.ai.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.qpharma.ai.data.entity.*
import com.qpharma.ai.data.repository.DashboardRepository
import com.qpharma.ai.data.repository.PrescriptionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Date
import javax.inject.Inject

/**
 * Dashboard ViewModel
 * Manages all dashboard state: visits, alerts, stats, reminders
 * Follows MVI pattern with sealed UI states
 */
@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val dashboardRepository: DashboardRepository,
    private val prescriptionRepository: PrescriptionRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        loadDashboardData()
    }

    private fun loadDashboardData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }

            dashboardRepository.getDashboardData()
                .catch { error ->
                    _uiState.update { 
                        it.copy(isLoading = false, error = error.message) 
                    }
                }
                .collect { data ->
                    _uiState.update { currentState ->
                        currentState.copy(
                            isLoading = false,
                            expectedVisits = data.expectedVisitsToday,
                            nearDepletionPatients = data.nearDepletionPatients,
                            todayStats = data.todayStats,
                            alerts = data.criticalAlerts,
                            lowStockItems = data.lowStockItems,
                            nearExpiryItems = data.nearExpiryItems,
                            error = null
                        )
                    }
                }
        }
    }

    fun refreshDashboard() {
        loadDashboardData()
    }

    fun dismissAlert(alertId: Long) {
        _uiState.update { state ->
            state.copy(alerts = state.alerts.filter { it.entityId != alertId })
        }
    }

    fun onPatientClick(patientId: Long) {
        // Navigation handled by UI layer
        _uiState.update { it.copy(selectedPatientId = patientId) }
    }

    fun onAlertAction(alert: DashboardAlert) {
        viewModelScope.launch {
            when (alert.type) {
                AlertType.LOW_STOCK -> {
                    // Navigate to product detail for reorder
                    _uiState.update { it.copy(navigateToProduct = alert.entityId) }
                }
                AlertType.EXPIRY -> {
                    // Navigate to expiry management
                    _uiState.update { it.copy(navigateToExpiry = alert.entityId) }
                }
                AlertType.DRUG_INTERACTION -> {
                    // Show interaction details
                    _uiState.update { it.copy(showInteractionDialog = alert.entityId) }
                }
                else -> { /* Handle other alert types */ }
            }
        }
    }
}

/**
 * Immutable UI State for Dashboard
 */
data class DashboardUiState(
    val isLoading: Boolean = true,
    val expectedVisits: List<Patient> = emptyList(),
    val nearDepletionPatients: List<Patient> = emptyList(),
    val todayStats: TodayStats = TodayStats(0.0, 0, 0, 0.0),
    val alerts: List<DashboardAlert> = emptyList(),
    val lowStockItems: List<Product> = emptyList(),
    val nearExpiryItems: List<Product> = emptyList(),
    val selectedPatientId: Long? = null,
    val navigateToProduct: Long? = null,
    val navigateToExpiry: Long? = null,
    val showInteractionDialog: Long? = null,
    val error: String? = null
)

//================================================================================
// FILE: ui/viewmodel/PrescriptionViewModel.kt
//================================================================================
package com.qpharma.ai.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.qpharma.ai.data.entity.*
import com.qpharma.ai.data.repository.PrescriptionRepository
import com.qpharma.ai.ai.DocumentProcessor
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Prescription ViewModel
 * Handles: AI prescription processing, dose calculation, auto-reminder scheduling
 * Manages 3-step flow: Input → AI Processing → Confirmation → Auto-Reminders
 */
@HiltViewModel
class PrescriptionViewModel @Inject constructor(
    private val prescriptionRepository: PrescriptionRepository,
    private val documentProcessor: DocumentProcessor
) : ViewModel() {

    private val _uiState = MutableStateFlow(PrescriptionUiState())
    val uiState: StateFlow<PrescriptionUiState> = _uiState.asStateFlow()

    private val _processingState = MutableStateFlow<ProcessingState>(ProcessingState.Idle)
    val processingState: StateFlow<ProcessingState> = _processingState.asStateFlow()

    /**
     * Step 1: Set input method and capture data
     */
    fun setInputMethod(method: PrescriptionInputMethod) {
        _uiState.update { it.copy(inputMethod = method) }
    }

    fun setCustomer(customerId: Long) {
        _uiState.update { it.copy(selectedCustomerId = customerId) }
    }

    fun captureImage(uri: Uri) {
        _uiState.update { it.copy(capturedImageUri = uri, inputMethod = PrescriptionInputMethod.CAMERA) }
    }

    fun setVoiceRecording(path: String) {
        _uiState.update { it.copy(voicePath = path, inputMethod = PrescriptionInputMethod.VOICE) }
    }

    fun setPdfPath(path: String) {
        _uiState.update { it.copy(pdfPath = path, inputMethod = PrescriptionInputMethod.PDF) }
    }

    fun addManualDrug(drug: ManualDrugInput) {
        val currentDrugs = _uiState.value.manualDrugs.toMutableList()
        currentDrugs.add(drug)
        _uiState.update { it.copy(manualDrugs = currentDrugs, inputMethod = PrescriptionInputMethod.MANUAL) }
    }

    /**
     * Step 2: Process prescription with AI
     * This triggers the full AI pipeline: OCR → NLP → Dose Calculation → Auto-Reminder
     */
    fun processPrescription() {
        viewModelScope.launch {
            val state = _uiState.value
            val customerId = state.selectedCustomerId ?: return@launch

            _processingState.value = ProcessingState.Processing("جاري تحليل الوصفة بالذكاء الاصطناعي...")

            val result = prescriptionRepository.processPrescription(
                customerId = customerId,
                inputMethod = state.inputMethod.name.lowercase(),
                imagePath = state.capturedImageUri?.path,
                voicePath = state.voicePath,
                pdfPath = state.pdfPath,
                manualDrugs = state.manualDrugs.takeIf { state.inputMethod == PrescriptionInputMethod.MANUAL }
            )

            result.onSuccess { prescriptionId ->
                _processingState.value = ProcessingState.Success(
                    message = "تم حفظ الوصفة وتفعيل المنبهات التلقائية بنجاح!",
                    prescriptionId = prescriptionId
                )
                // Reset state for next prescription
                _uiState.update { PrescriptionUiState() }

            }.onFailure { error ->
                _processingState.value = ProcessingState.Error(
                    message = error.message ?: "حدث خطأ أثناء المعالجة",
                    canRetry = true
                )
            }
        }
    }

    /**
     * Retry processing after failure
     */
    fun retryProcessing() {
        _processingState.value = ProcessingState.Idle
        processPrescription()
    }

    /**
     * Preview extracted items before confirmation
     */
    fun previewExtractedItems() {
        // Show AI-extracted items for user confirmation
        _uiState.update { it.copy(showPreview = true) }
    }

    fun confirmPrescription() {
        _uiState.update { it.copy(showPreview = false) }
        processPrescription()
    }

    fun cancelProcessing() {
        _processingState.value = ProcessingState.Idle
        _uiState.update { PrescriptionUiState() }
    }

    /**
     * Load prescription history for a customer
     */
    fun loadCustomerPrescriptions(customerId: Long) {
        viewModelScope.launch {
            prescriptionRepository.getPrescriptionsByCustomer(customerId)
                .catch { /* Handle error */ }
                .collect { prescriptions ->
                    _uiState.update { it.copy(prescriptionHistory = prescriptions) }
                }
        }
    }
}

/**
 * UI State for Prescription Screen
 */
data class PrescriptionUiState(
    val selectedCustomerId: Long? = null,
    val inputMethod: PrescriptionInputMethod = PrescriptionInputMethod.MANUAL,
    val capturedImageUri: Uri? = null,
    val voicePath: String? = null,
    val pdfPath: String? = null,
    val manualDrugs: List<ManualDrugInput> = emptyList(),
    val extractedItems: List<PrescriptionItemData> = emptyList(),
    val showPreview: Boolean = false,
    val prescriptionHistory: List<PrescriptionWithPatient> = emptyList(),
    val error: String? = null
)

enum class PrescriptionInputMethod {
    MANUAL, CAMERA, VOICE, PDF
}

/**
 * Sealed class for processing states
 */
sealed class ProcessingState {
    object Idle : ProcessingState()
    data class Processing(val message: String) : ProcessingState()
    data class Success(val message: String, val prescriptionId: Long) : ProcessingState()
    data class Error(val message: String, val canRetry: Boolean) : ProcessingState()
}

//================================================================================
// FILE: ui/viewmodel/DocumentViewModel.kt
//================================================================================
package com.qpharma.ai.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.qpharma.ai.ai.DocumentProcessor
import com.qpharma.ai.data.entity.Document
import com.qpharma.ai.data.dao.DocumentDao
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Document Processing ViewModel
 * Manages: PDF → Excel conversion, Invoice capture, Voice editing
 */
@HiltViewModel
class DocumentViewModel @Inject constructor(
    private val documentProcessor: DocumentProcessor,
    private val documentDao: DocumentDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(DocumentUiState())
    val uiState: StateFlow<DocumentUiState> = _uiState.asStateFlow()

    val documents = documentDao.getAllDocuments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectPdfFile(uri: Uri) {
        _uiState.update { it.copy(selectedPdfUri = uri, currentOperation = DocumentOperation.PDF_TO_EXCEL) }
    }

    fun captureInvoiceImage(uri: Uri) {
        _uiState.update { it.copy(capturedImageUri = uri, currentOperation = DocumentOperation.INVOICE_CAPTURE) }
    }

    /**
     * Convert PDF to Excel with progress tracking
     */
    fun convertPdfToExcel() {
        viewModelScope.launch {
            val pdfPath = _uiState.value.selectedPdfUri?.path ?: return@launch

            _uiState.update { it.copy(isProcessing = true, progress = 0, statusMessage = "جاري قراءة ملف PDF...") }

            val result = documentProcessor.pdfToExcel(pdfPath) { current, total ->
                val progressPercent = (current * 100 / total)
                _uiState.update { 
                    it.copy(
                        progress = progressPercent,
                        statusMessage = "معالجة الصفحة $current من $total"
                    )
                }
            }

            result.onSuccess { excelPath ->
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        progress = 100,
                        statusMessage = "تم التحويل بنجاح!",
                        outputFilePath = excelPath
                    )
                }
                // Save to document history
                saveDocumentRecord(pdfPath, excelPath, "pdf_to_excel")

            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        statusMessage = "فشل التحويل: ${error.message}",
                        error = error.message
                    )
                }
            }
        }
    }

    /**
     * Process captured invoice image with AI
     */
    fun processInvoiceImage() {
        viewModelScope.launch {
            val imagePath = _uiState.value.capturedImageUri?.path ?: return@launch

            _uiState.update { it.copy(isProcessing = true, statusMessage = "جاري قراءة الفاتورة بالذكاء الاصطناعي...") }

            val result = documentProcessor.processInvoiceImage(imagePath)

            _uiState.update {
                it.copy(
                    isProcessing = false,
                    extractedInvoiceItems = result.items,
                    statusMessage = "تم استخراج ${result.items.size} أصناف بنجاح",
                    aiConfidence = result.confidence
                )
            }
        }
    }

    /**
     * Voice command for Excel cell editing
     * Example: "غيّر السعر في الصف 5 إلى 1500"
     */
    fun executeVoiceEdit(voiceCommand: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true, statusMessage = "جاري تنفيذ الأمر الصوتي...") }

            // Parse voice command using Arabic NLP
            val editResult = parseVoiceEditCommand(voiceCommand)

            _uiState.update {
                it.copy(
                    isProcessing = false,
                    voiceEditResult = editResult,
                    statusMessage = "تم التعديل: ${editResult.description}"
                )
            }
        }
    }

    private fun parseVoiceEditCommand(command: String): VoiceEditResult {
        // Arabic command parsing
        return when {
            command.contains("غيّر") || command.contains("عدّل") -> {
                // Extract row, column, and new value
                val rowMatch = Regex("(الصف|صف)\s*(\d+)").find(command)
                val valueMatch = Regex("(إلى|بـ)\s*(\d+)").find(command)

                VoiceEditResult(
                    action = "update_cell",
                    row = rowMatch?.groupValues?.get(2)?.toIntOrNull(),
                    newValue = valueMatch?.groupValues?.get(2),
                    description = "تعديل الصف ${rowMatch?.groupValues?.get(2)} إلى ${valueMatch?.groupValues?.get(2)}"
                )
            }
            command.contains("احذف") || command.contains("امسح") -> {
                val rowMatch = Regex("(الصف|صف)\s*(\d+)").find(command)
                VoiceEditResult(
                    action = "delete_row",
                    row = rowMatch?.groupValues?.get(2)?.toIntOrNull(),
                    description = "حذف الصف ${rowMatch?.groupValues?.get(2)}"
                )
            }
            command.contains("أضف") || command.contains("ضيف") -> {
                VoiceEditResult(
                    action = "add_row",
                    description = "إضافة صف جديد"
                )
            }
            else -> VoiceEditResult(action = "unknown", description = "لم يتم التعرف على الأمر")
        }
    }

    private suspend fun saveDocumentRecord(sourcePath: String, outputPath: String, operation: String) {
        val document = Document(
            fileName = sourcePath.substringAfterLast("/"),
            filePath = sourcePath,
            fileType = "pdf",
            sourceType = "imported",
            excelExportPath = outputPath,
            processingStatus = "completed"
        )
        documentDao.insertDocument(document)
    }

    fun resetState() {
        _uiState.value = DocumentUiState()
    }
}

data class DocumentUiState(
    val selectedPdfUri: Uri? = null,
    val capturedImageUri: Uri? = null,
    val currentOperation: DocumentOperation? = null,
    val isProcessing: Boolean = false,
    val progress: Int = 0,
    val statusMessage: String = "",
    val outputFilePath: String? = null,
    val extractedInvoiceItems: List<InvoiceItemData> = emptyList(),
    val aiConfidence: Float = 0f,
    val voiceEditResult: VoiceEditResult? = null,
    val error: String? = null
)

enum class DocumentOperation {
    PDF_TO_EXCEL, INVOICE_CAPTURE, VOICE_EDIT
}

data class VoiceEditResult(
    val action: String,
    val row: Int? = null,
    val column: String? = null,
    val newValue: String? = null,
    val description: String
)
