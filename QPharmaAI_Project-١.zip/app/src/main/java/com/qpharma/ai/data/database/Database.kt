
//================================================================================
// FILE: data/database/QPharmaDatabase.kt
//================================================================================
package com.qpharma.ai.data.database

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.qpharma.ai.data.dao.*
import com.qpharma.ai.data.entity.*
import com.qpharma.ai.data.converter.DateConverter
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory

@Database(
    entities = [
        Patient::class, Product::class, Invoice::class, InvoiceItem::class,
        Cashbox::class, CashboxTransaction::class, Prescription::class,
        PrescriptionItem::class, MedicationReminder::class, Document::class,
        Supplier::class, SupplierInvoice::class, PaymentReceipt::class,
        MarketingCampaign::class, MarketingDesign::class, MessageTemplate::class,
        SentMessage::class, AutomationRule::class, CustomerPrice::class,
        CustomerVisit::class, DrugInteraction::class, StockMovement::class,
        AppSetting::class, User::class, AuditLog::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(DateConverter::class)
abstract class QPharmaDatabase : RoomDatabase() {

    abstract fun patientDao(): PatientDao
    abstract fun productDao(): ProductDao
    abstract fun invoiceDao(): InvoiceDao
    abstract fun cashboxDao(): CashboxDao
    abstract fun prescriptionDao(): PrescriptionDao
    abstract fun medicationReminderDao(): MedicationReminderDao
    abstract fun documentDao(): DocumentDao
    abstract fun supplierDao(): SupplierDao
    abstract fun marketingDao(): MarketingDao
    abstract fun messageDao(): MessageDao
    abstract fun automationDao(): AutomationDao
    abstract fun userDao(): UserDao

    companion object {
        @Volatile
        private var INSTANCE: QPharmaDatabase? = null

        fun getInstance(context: Context, passphrase: String): QPharmaDatabase {
            return INSTANCE ?: synchronized(this) {
                val factory = SupportFactory(SQLiteDatabase.getBytes(passphrase.toCharArray()))

                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    QPharmaDatabase::class.java,
                    "qpharma_encrypted.db"
                )
                    .openHelperFactory(factory)
                    .addCallback(DatabaseCallback())
                    .build()

                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            // Seed default data
            db.execSQL("""
                INSERT INTO cashboxes (name, type, balance, currency, is_active) 
                VALUES ('الصندوق النقدي', 'cash', 0.0, 'YER', 1)
            """)
            db.execSQL("""
                INSERT INTO app_settings (setting_key, setting_value, setting_group) 
                VALUES 
                ('reminder_days_before', '3', 'prescription'),
                ('default_language', 'ar', 'app'),
                ('dark_mode', 'system', 'ui'),
                ('auto_sync', 'true', 'sync'),
                ('business_name', 'صيدليتي', 'business')
            """)
        }
    }
}

//================================================================================
// FILE: data/converter/DateConverter.kt
//================================================================================
package com.qpharma.ai.data.converter

import androidx.room.TypeConverter
import java.util.Date

class DateConverter {
    @TypeConverter
    fun fromTimestamp(value: Long?): Date? {
        return value?.let { Date(it) }
    }

    @TypeConverter
    fun dateToTimestamp(date: Date?): Long? {
        return date?.time
    }
}

//================================================================================
// FILE: data/repository/PrescriptionRepository.kt
//================================================================================
package com.qpharma.ai.data.repository

import com.qpharma.ai.data.dao.*
import com.qpharma.ai.data.entity.*
import com.qpharma.ai.ai.PrescriptionAIProcessor
import com.qpharma.ai.worker.ReminderScheduler
import kotlinx.coroutines.flow.Flow
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PrescriptionRepository @Inject constructor(
    private val prescriptionDao: PrescriptionDao,
    private val medicationReminderDao: MedicationReminderDao,
    private val aiProcessor: PrescriptionAIProcessor,
    private val reminderScheduler: ReminderScheduler
) {
    fun getAllPrescriptions(): Flow<List<PrescriptionWithPatient>> = 
        prescriptionDao.getAllPrescriptionsWithPatient()

    fun getPrescriptionsByCustomer(customerId: Long): Flow<List<PrescriptionWithPatient>> = 
        prescriptionDao.getPrescriptionsByCustomer(customerId)

    suspend fun processPrescription(
        customerId: Long,
        inputMethod: String,
        imagePath: String? = null,
        voicePath: String? = null,
        pdfPath: String? = null,
        manualDrugs: List<ManualDrugInput>? = null
    ): Result<Long> {
        return try {
            // 1. Create prescription record
            val prescription = Prescription(
                customerId = customerId,
                inputMethod = inputMethod,
                imagePath = imagePath,
                voicePath = voicePath,
                pdfPath = pdfPath
            )
            val prescriptionId = prescriptionDao.insertPrescription(prescription)

            // 2. AI Processing based on input type
            val extractedItems = when (inputMethod) {
                "camera", "pdf" -> {
                    val imageToProcess = imagePath ?: pdfPath
                    aiProcessor.extractFromImage(imageToProcess!!)
                }
                "voice" -> aiProcessor.extractFromVoice(voicePath!!)
                "manual" -> manualDrugs?.map { 
                    PrescriptionItemData(
                        drugName = it.name,
                        concentration = it.concentration,
                        quantity = it.quantity,
                        dosage = it.dosage,
                        frequency = it.frequency,
                        packageQty = it.packageQty
                    )
                } ?: emptyList()
                else -> emptyList()
            }

            // 3. Save extracted items with AI-calculated end dates
            val prescriptionItems = extractedItems.map { item ->
                val endDate = calculateEndDate(
                    packageQty = item.packageQty ?: 30,
                    dosage = item.dosage ?: "1",
                    frequency = item.frequency ?: "يومياً"
                )

                PrescriptionItem(
                    prescriptionId = prescriptionId,
                    drugName = item.drugName,
                    concentration = item.concentration,
                    quantity = item.quantity,
                    dosage = item.dosage,
                    frequency = item.frequency,
                    durationDays = item.durationDays,
                    packageQty = item.packageQty,
                    packageType = item.packageType,
                    aiCalculatedEndDate = endDate
                )
            }

            prescriptionDao.insertPrescriptionItems(prescriptionItems)

            // 4. SILENT AUTO-REMINDER CREATION (No user interaction required)
            createAutoReminders(customerId, prescriptionItems)

            // 5. Update prescription status
            prescriptionDao.updateStatus(prescriptionId, "confirmed")

            Result.success(prescriptionId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Calculates medication end date based on package quantity, dosage, and frequency
     * Example: 60 pills, 2 pills daily = 30 days supply
     */
    private fun calculateEndDate(
        packageQty: Int,
        dosage: String,
        frequency: String
    ): Date {
        val dailyDose = parseDailyDose(dosage, frequency)
        val daysSupply = (packageQty / dailyDose).toInt()

        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_YEAR, daysSupply)
        return calendar.time
    }

    private fun parseDailyDose(dosage: String, frequency: String): Double {
        // Parse Arabic dosage: "حبتين" → 2, "3 مرات يومياً" → 3
        val doseCount = extractNumberFromArabic(dosage)
        val freqCount = extractFrequencyCount(frequency)
        return doseCount * freqCount
    }

    private fun extractNumberFromArabic(text: String): Double {
        val arabicNumbers = mapOf(
            "حبة" to 1.0, "حبتين" to 2.0, "حبتان" to 2.0,
            "3" to 3.0, "ثلاث" to 3.0, "ثلاثة" to 3.0,
            "4" to 4.0, "أربع" to 4.0, "أربعة" to 4.0
        )
        return arabicNumbers.entries.firstOrNull { text.contains(it.key) }?.value ?: 1.0
    }

    private fun extractFrequencyCount(frequency: String): Double {
        return when {
            frequency.contains("3") || frequency.contains("ثلاث") -> 3.0
            frequency.contains("2") || frequency.contains("مرتين") -> 2.0
            frequency.contains("4") || frequency.contains("أربع") -> 4.0
            else -> 1.0
        }
    }

    /**
     * SILENT AUTO-REMINDER CREATION
     * Creates reminders automatically without user interaction
     * Triggered 3 days (configurable) before medication runs out
     */
    private suspend fun createAutoReminders(
        customerId: Long,
        items: List<PrescriptionItem>
    ) {
        val safetyDays = getSafetyDaysFromSettings() // Default: 3 days

        val reminders = items.mapNotNull { item ->
            item.aiCalculatedEndDate?.let { endDate ->
                val reminderCalendar = Calendar.getInstance()
                reminderCalendar.time = endDate
                reminderCalendar.add(Calendar.DAY_OF_YEAR, -safetyDays)

                val reminderDate = reminderCalendar.time

                // Only create if reminder date is in the future
                if (reminderDate.after(Date())) {
                    MedicationReminder(
                        customerId = customerId,
                        prescriptionItemId = item.id,
                        drugName = item.drugName,
                        reminderDate = reminderDate,
                        reminderTime = "09:00", // Default morning reminder
                        message = buildReminderMessage(item.drugName, endDate),
                        channel = "whatsapp",
                        autoCreated = true,
                        daysBeforeRunout = safetyDays
                    )
                } else null
            }
        }

        if (reminders.isNotEmpty()) {
            medicationReminderDao.insertReminders(reminders)

            // Schedule WorkManager alarms for each reminder
            reminders.forEach { reminder ->
                reminderScheduler.scheduleReminder(reminder)
            }
        }
    }

    private fun buildReminderMessage(drugName: String, endDate: Date): String {
        val dateStr = android.text.format.DateFormat.format("dd/MM/yyyy", endDate)
        return """
            مرحباً عزيزي العميل،

            نود تذكيرك بأن دواء **$drugName** سينتهي بتاريخ $dateStr.

            يرجى زيارة الصيدلية لإعادة صرف وصفتك وضمان استمرارية علاجك.

            مع تحيات صيدلية Q-Pharma
        """.trimIndent()
    }

    private suspend fun getSafetyDaysFromSettings(): Int {
        // Read from app_settings table, default to 3
        return 3
    }

    suspend fun getPrescriptionWithItems(prescriptionId: Long): PrescriptionWithItems {
        return prescriptionDao.getPrescriptionWithItems(prescriptionId)
    }

    suspend fun deletePrescription(prescriptionId: Long) {
        // Also delete associated reminders
        val prescription = prescriptionDao.getPrescriptionWithItems(prescriptionId)
        prescription.items.forEach { item ->
            medicationReminderDao.deleteRemindersByItem(item.id)
        }
        // Note: Cascade delete will handle the prescription itself
    }
}

// Data class for manual drug input
data class ManualDrugInput(
    val name: String,
    val concentration: String? = null,
    val quantity: Int = 1,
    val dosage: String? = null,
    val frequency: String? = null,
    val packageQty: Int? = null
)

// Data class for AI-extracted prescription items
data class PrescriptionItemData(
    val drugName: String,
    val concentration: String? = null,
    val quantity: Int = 1,
    val dosage: String? = null,
    val frequency: String? = null,
    val durationDays: Int? = null,
    val packageQty: Int? = null,
    val packageType: String? = null
)

//================================================================================
// FILE: data/repository/DashboardRepository.kt
//================================================================================
package com.qpharma.ai.data.repository

import com.qpharma.ai.data.dao.*
import com.qpharma.ai.data.entity.*
import kotlinx.coroutines.flow.*
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DashboardRepository @Inject constructor(
    private val patientDao: PatientDao,
    private val invoiceDao: InvoiceDao,
    private val productDao: ProductDao,
    private val medicationReminderDao: MedicationReminderDao,
    private val prescriptionDao: PrescriptionDao
) {
    /**
     * Fetches all dashboard data as a combined Flow
     * This is the single source of truth for the Dashboard screen
     */
    fun getDashboardData(): Flow<DashboardData> = combine(
        getExpectedVisitsToday(),
        getNearDepletionPatients(),
        getTodayStats(),
        getCriticalAlerts(),
        getLowStockItems(),
        getNearExpiryItems()
    ) { visits, depletion, stats, alerts, lowStock, expiry ->
        DashboardData(
            expectedVisitsToday = visits,
            nearDepletionPatients = depletion,
            todayStats = stats,
            criticalAlerts = alerts,
            lowStockItems = lowStock,
            nearExpiryItems = expiry
        )
    }

    private fun getExpectedVisitsToday(): Flow<List<Patient>> {
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
        }.time
        return patientDao.getChronicPatientsWithUpcomingReminders(today)
    }

    private fun getNearDepletionPatients(): Flow<List<Patient>> {
        val threshold = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 3)
        }.time
        return prescriptionDao.getItemsNearDepletion(threshold)
            .map { items -> items.map { /* fetch patient by id */ } }
    }

    private fun getTodayStats(): Flow<TodayStats> = flow {
        val summary = invoiceDao.getTodaySalesSummary()
        val reminderCount = medicationReminderDao.getPendingReminderCount(Date())
        emit(TodayStats(
            totalSales = summary.dailyTotal ?: 0.0,
            invoiceCount = summary.invoiceCount ?: 0,
            pendingReminders = reminderCount,
            totalDebt = 0.0 // Calculate from invoices
        ))
    }

    private fun getCriticalAlerts(): Flow<List<DashboardAlert>> = combine(
        productDao.getLowStockProducts(),
        productDao.getNearExpiryProducts()
    ) { lowStock, expiry ->
        val alerts = mutableListOf<DashboardAlert>()

        lowStock.forEach { product ->
            alerts.add(DashboardAlert(
                type = AlertType.LOW_STOCK,
                title = "نقص مخزون: ${product.name}",
                description = "الكمية المتبقية: ${product.quantity} (الحد الأدنى: ${product.minStock})",
                severity = AlertSeverity.HIGH,
                entityId = product.id,
                entityType = "product"
            ))
        }

        expiry.forEach { product ->
            alerts.add(DashboardAlert(
                type = AlertType.EXPIRY,
                title = "اقتراب انتهاء الصلاحية: ${product.name}",
                description = "تاريخ الانتهاء: ${product.expiryDate}",
                severity = AlertSeverity.MEDIUM,
                entityId = product.id,
                entityType = "product"
            ))
        }

        alerts
    }

    private fun getLowStockItems(): Flow<List<Product>> = productDao.getLowStockProducts()

    private fun getNearExpiryItems(): Flow<List<Product>> = productDao.getNearExpiryProducts()
}

// Dashboard data models
data class DashboardData(
    val expectedVisitsToday: List<Patient>,
    val nearDepletionPatients: List<Patient>,
    val todayStats: TodayStats,
    val criticalAlerts: List<DashboardAlert>,
    val lowStockItems: List<Product>,
    val nearExpiryItems: List<Product>
)

data class TodayStats(
    val totalSales: Double,
    val invoiceCount: Int,
    val pendingReminders: Int,
    val totalDebt: Double
)

data class DashboardAlert(
    val type: AlertType,
    val title: String,
    val description: String,
    val severity: AlertSeverity,
    val entityId: Long,
    val entityType: String,
    val timestamp: Date = Date()
)

enum class AlertType {
    LOW_STOCK, EXPIRY, DRUG_INTERACTION, PAYMENT_DUE, SYSTEM
}

enum class AlertSeverity {
    LOW, MEDIUM, HIGH, CRITICAL
}
