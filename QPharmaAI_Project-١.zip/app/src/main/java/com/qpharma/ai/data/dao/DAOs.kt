
//================================================================================
// FILE: data/dao/PatientDao.kt
//================================================================================
package com.qpharma.ai.data.dao

import androidx.room.*
import com.qpharma.ai.data.entity.*
import kotlinx.coroutines.flow.Flow
import java.util.Date

@Dao
interface PatientDao {

    @Query("SELECT * FROM patients WHERE isActive = 1 ORDER BY name ASC")
    fun getAllPatients(): Flow<List<Patient>>

    @Query("SELECT * FROM patients WHERE id = :patientId")
    suspend fun getPatientById(patientId: Long): Patient?

    @Query("SELECT * FROM patients WHERE phone LIKE '%' || :query || '%' OR name LIKE '%' || :query || '%' ORDER BY name ASC")
    fun searchPatients(query: String): Flow<List<Patient>>

    @Query("""
        SELECT * FROM patients 
        WHERE customer_type = 'chronic' 
        AND id IN (
            SELECT customer_id FROM medication_reminders 
            WHERE reminder_date <= :date AND status = 'scheduled'
        )
        ORDER BY name ASC
    """)
    fun getChronicPatientsWithUpcomingReminders(date: Date): Flow<List<Patient>>

    @Query("""
        SELECT p.*, COUNT(i.id) as visit_count, SUM(i.net_amount) as total_spent
        FROM patients p
        LEFT JOIN invoices i ON p.id = i.customer_id
        WHERE p.isActive = 1
        GROUP BY p.id
        ORDER BY total_spent DESC
    """)
    fun getPatientsWithProfitability(): Flow<List<PatientWithStats>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPatient(patient: Patient): Long

    @Update
    suspend fun updatePatient(patient: Patient)

    @Delete
    suspend fun deletePatient(patient: Patient)

    @Query("UPDATE patients SET loyalty_points = loyalty_points + :points WHERE id = :patientId")
    suspend fun addLoyaltyPoints(patientId: Long, points: Int)

    @Query("SELECT * FROM patients WHERE qr_code = :qrCode LIMIT 1")
    suspend fun getPatientByQrCode(qrCode: String): Patient?
}

// Data class for patient statistics
data class PatientWithStats(
    @Embedded val patient: Patient,
    val visitCount: Int,
    val totalSpent: Double
)

//================================================================================
// FILE: data/dao/InvoiceDao.kt
//================================================================================
package com.qpharma.ai.data.dao

import androidx.room.*
import com.qpharma.ai.data.entity.*
import kotlinx.coroutines.flow.Flow
import java.util.Date

@Dao
interface InvoiceDao {

    @Query("""
        SELECT i.*, p.name as customer_name, p.phone as customer_phone
        FROM invoices i
        LEFT JOIN patients p ON i.customer_id = p.id
        ORDER BY i.created_at DESC
    """)
    fun getAllInvoicesWithCustomer(): Flow<List<InvoiceWithCustomer>>

    @Query("""
        SELECT i.*, p.name as customer_name 
        FROM invoices i
        LEFT JOIN patients p ON i.customer_id = p.id
        WHERE i.customer_id = :customerId
        ORDER BY i.created_at DESC
    """)
    fun getInvoicesByCustomer(customerId: Long): Flow<List<InvoiceWithCustomer>>

    @Query("""
        SELECT SUM(total_profit) as total_profit, SUM(net_amount) as total_revenue
        FROM invoices i
        JOIN invoice_items ii ON i.id = ii.invoice_id
        WHERE i.customer_id = :customerId
        AND i.created_at BETWEEN :startDate AND :endDate
    """)
    suspend fun getCustomerProfitability(
        customerId: Long, 
        startDate: Date, 
        endDate: Date
    ): CustomerProfitSummary

    @Query("""
        SELECT SUM(net_amount) as daily_total, COUNT(*) as invoice_count
        FROM invoices
        WHERE date(created_at / 1000, 'unixepoch') = date('now')
    """)
    suspend fun getTodaySalesSummary(): DailySalesSummary

    @Transaction
    @Query("SELECT * FROM invoices WHERE id = :invoiceId")
    suspend fun getInvoiceWithItems(invoiceId: Long): InvoiceWithItems

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: Invoice): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoiceItems(items: List<InvoiceItem>)

    @Update
    suspend fun updateInvoice(invoice: Invoice)

    @Query("UPDATE invoices SET paid_amount = paid_amount + :amount, remaining = remaining - :amount WHERE id = :invoiceId")
    suspend fun updatePayment(invoiceId: Long, amount: Double)
}

// Composite data classes
data class InvoiceWithCustomer(
    @Embedded val invoice: Invoice,
    val customerName: String?,
    val customerPhone: String?
)

data class InvoiceWithItems(
    @Embedded val invoice: Invoice,
    @Relation(
        parentColumn = "id",
        entityColumn = "invoice_id"
    )
    val items: List<InvoiceItemWithProduct>
)

data class InvoiceItemWithProduct(
    @Embedded val item: InvoiceItem,
    @Relation(
        parentColumn = "product_id",
        entityColumn = "id"
    )
    val product: Product
)

data class CustomerProfitSummary(
    val totalProfit: Double?,
    val totalRevenue: Double?
)

data class DailySalesSummary(
    val dailyTotal: Double?,
    val invoiceCount: Int?
)

//================================================================================
// FILE: data/dao/PrescriptionDao.kt
//================================================================================
package com.qpharma.ai.data.dao

import androidx.room.*
import com.qpharma.ai.data.entity.*
import kotlinx.coroutines.flow.Flow
import java.util.Date

@Dao
interface PrescriptionDao {

    @Query("""
        SELECT pr.*, p.name as patient_name 
        FROM prescriptions pr
        JOIN patients p ON pr.customer_id = p.id
        ORDER BY pr.created_at DESC
    """)
    fun getAllPrescriptionsWithPatient(): Flow<List<PrescriptionWithPatient>>

    @Query("""
        SELECT pr.*, p.name as patient_name 
        FROM prescriptions pr
        JOIN patients p ON pr.customer_id = p.id
        WHERE pr.customer_id = :customerId
        ORDER BY pr.created_at DESC
    """)
    fun getPrescriptionsByCustomer(customerId: Long): Flow<List<PrescriptionWithPatient>>

    @Transaction
    @Query("SELECT * FROM prescriptions WHERE id = :prescriptionId")
    suspend fun getPrescriptionWithItems(prescriptionId: Long): PrescriptionWithItems

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrescription(prescription: Prescription): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrescriptionItems(items: List<PrescriptionItem>)

    @Query("""
        SELECT pi.*, p.name as patient_name, p.phone as patient_phone
        FROM prescription_items pi
        JOIN prescriptions pr ON pi.prescription_id = pr.id
        JOIN patients p ON pr.customer_id = p.id
        WHERE pi.ai_calculated_end_date IS NOT NULL
        AND pi.ai_calculated_end_date <= :thresholdDate
        ORDER BY pi.ai_calculated_end_date ASC
    """)
    fun getItemsNearDepletion(thresholdDate: Date): Flow<List<PrescriptionItemWithPatient>>

    @Query("UPDATE prescriptions SET status = :status WHERE id = :prescriptionId")
    suspend fun updateStatus(prescriptionId: Long, status: String)
}

data class PrescriptionWithPatient(
    @Embedded val prescription: Prescription,
    val patientName: String
)

data class PrescriptionWithItems(
    @Embedded val prescription: Prescription,
    @Relation(
        parentColumn = "id",
        entityColumn = "prescription_id"
    )
    val items: List<PrescriptionItem>
)

data class PrescriptionItemWithPatient(
    @Embedded val item: PrescriptionItem,
    val patientName: String,
    val patientPhone: String?
)

//================================================================================
// FILE: data/dao/MedicationReminderDao.kt
//================================================================================
package com.qpharma.ai.data.dao

import androidx.room.*
import com.qpharma.ai.data.entity.*
import kotlinx.coroutines.flow.Flow
import java.util.Date

@Dao
interface MedicationReminderDao {

    @Query("""
        SELECT mr.*, p.name as patient_name, p.phone as patient_phone
        FROM medication_reminders mr
        JOIN patients p ON mr.customer_id = p.id
        WHERE mr.reminder_date <= :date
        AND mr.status = 'scheduled'
        ORDER BY mr.reminder_date ASC, mr.reminder_time ASC
    """)
    fun getPendingReminders(date: Date): Flow<List<ReminderWithPatient>>

    @Query("""
        SELECT mr.*, p.name as patient_name, p.phone as patient_phone
        FROM medication_reminders mr
        JOIN patients p ON mr.customer_id = p.id
        WHERE mr.customer_id = :customerId
        AND mr.status = 'scheduled'
        ORDER BY mr.reminder_date ASC
    """)
    fun getRemindersByCustomer(customerId: Long): Flow<List<ReminderWithPatient>>

    @Query("SELECT COUNT(*) FROM medication_reminders WHERE status = 'scheduled' AND reminder_date <= :date")
    suspend fun getPendingReminderCount(date: Date): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: MedicationReminder): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminders(reminders: List<MedicationReminder>)

    @Query("UPDATE medication_reminders SET status = :status WHERE id = :reminderId")
    suspend fun updateStatus(reminderId: Long, status: String)

    @Query("DELETE FROM medication_reminders WHERE prescription_item_id = :itemId")
    suspend fun deleteRemindersByItem(itemId: Long)
}

data class ReminderWithPatient(
    @Embedded val reminder: MedicationReminder,
    val patientName: String,
    val patientPhone: String?
)

//================================================================================
// FILE: data/dao/ProductDao.kt
//================================================================================
package com.qpharma.ai.data.dao

import androidx.room.*
import com.qpharma.ai.data.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {

    @Query("SELECT * FROM products WHERE isActive = 1 ORDER BY name ASC")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE quantity <= min_stock AND isActive = 1")
    fun getLowStockProducts(): Flow<List<Product>>

    @Query("""
        SELECT * FROM products 
        WHERE expiry_date IS NOT NULL 
        AND expiry_date <= date('now', '+30 days')
        AND isActive = 1
        ORDER BY expiry_date ASC
    """)
    fun getNearExpiryProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE barcode = :barcode LIMIT 1")
    suspend fun getProductByBarcode(barcode: String): Product?

    @Query("""
        SELECT p.*, cp.custom_price, cp.discount_percent
        FROM products p
        LEFT JOIN customer_prices cp ON p.id = cp.product_id AND cp.customer_id = :customerId AND cp.is_active = 1
        WHERE p.isActive = 1
        ORDER BY p.name ASC
    """)
    fun getProductsWithCustomerPrices(customerId: Long): Flow<List<ProductWithCustomerPrice>>

    @Query("""
        SELECT p.* FROM products p
        WHERE p.id IN (
            SELECT drug_a_id FROM drug_interactions WHERE drug_b_id = :drugId AND severity = 'critical'
            UNION
            SELECT drug_b_id FROM drug_interactions WHERE drug_a_id = :drugId AND severity = 'critical'
        )
    """)
    suspend fun getCriticalInteractions(drugId: Long): List<Product>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product): Long

    @Update
    suspend fun updateProduct(product: Product)

    @Query("UPDATE products SET quantity = quantity - :qty WHERE id = :productId")
    suspend fun deductStock(productId: Long, qty: Int)
}

data class ProductWithCustomerPrice(
    @Embedded val product: Product,
    val customPrice: Double?,
    val discountPercent: Double?
)

//================================================================================
// FILE: data/dao/DocumentDao.kt
//================================================================================
package com.qpharma.ai.data.dao

import androidx.room.*
import com.qpharma.ai.data.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DocumentDao {

    @Query("SELECT * FROM documents ORDER BY created_at DESC")
    fun getAllDocuments(): Flow<List<Document>>

    @Query("SELECT * FROM documents WHERE file_type = :type ORDER BY created_at DESC")
    fun getDocumentsByType(type: String): Flow<List<Document>>

    @Query("SELECT * FROM documents WHERE processing_status = :status")
    fun getDocumentsByStatus(status: String): Flow<List<Document>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(document: Document): Long

    @Query("UPDATE documents SET processing_status = :status, extracted_data = :data WHERE id = :docId")
    suspend fun updateProcessingStatus(docId: Long, status: String, data: String?)

    @Query("UPDATE documents SET excel_export_path = :path WHERE id = :docId")
    suspend fun updateExcelPath(docId: Long, path: String)

    @Delete
    suspend fun deleteDocument(document: Document)
}

//================================================================================
// FILE: data/dao/SupplierDao.kt
//================================================================================
package com.qpharma.ai.data.dao

import androidx.room.*
import com.qpharma.ai.data.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SupplierDao {

    @Query("SELECT * FROM suppliers WHERE isActive = 1 ORDER BY name ASC")
    fun getAllSuppliers(): Flow<List<Supplier>>

    @Query("SELECT * FROM suppliers WHERE balance > 0 ORDER BY balance DESC")
    fun getSuppliersWithBalance(): Flow<List<Supplier>>

    @Transaction
    @Query("SELECT * FROM suppliers WHERE id = :supplierId")
    suspend fun getSupplierWithInvoices(supplierId: Long): SupplierWithInvoices

    @Query("""
        SELECT pr.*, s.name as supplier_name
        FROM payment_receipts pr
        JOIN suppliers s ON pr.supplier_id = s.id
        WHERE pr.voucher_status = 'draft'
        ORDER BY pr.created_at DESC
    """)
    fun getPendingReceipts(): Flow<List<PaymentReceiptWithSupplier>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupplier(supplier: Supplier): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPaymentReceipt(receipt: PaymentReceipt): Long

    @Query("UPDATE payment_receipts SET voucher_status = :status, approved_by = :approvedBy, approved_at = :approvedAt WHERE id = :receiptId")
    suspend fun approveReceipt(receiptId: Long, status: String, approvedBy: String, approvedAt: java.util.Date)

    @Query("UPDATE suppliers SET balance = balance + :amount WHERE id = :supplierId")
    suspend fun updateSupplierBalance(supplierId: Long, amount: Double)
}

data class SupplierWithInvoices(
    @Embedded val supplier: Supplier,
    @Relation(
        parentColumn = "id",
        entityColumn = "supplier_id"
    )
    val invoices: List<SupplierInvoice>
)

data class PaymentReceiptWithSupplier(
    @Embedded val receipt: PaymentReceipt,
    val supplierName: String
)
