
//================================================================================
// FILE: ui/screens/settings/SettingsScreen.kt
//================================================================================
package com.qpharma.ai.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.qpharma.ai.ui.theme.QPharmaColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit = {}
) {
    var showAutomationSettings by remember { mutableStateOf(false) }
    var showReminderSettings by remember { mutableStateOf(false) }
    var showSecuritySettings by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الإعدادات", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = QPharmaColors.Background
                )
            )
        },
        containerColor = QPharmaColors.Background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Business Info
            item {
                SettingsSectionHeader("معلومات الصيدلية")
            }
            item {
                SettingsCard {
                    SettingsItem(
                        icon = Icons.Default.Store,
                        title = "اسم الصيدلية",
                        subtitle = "Q-Pharma",
                        onClick = {}
                    )
                    SettingsItem(
                        icon = Icons.Default.LocationOn,
                        title = "العنوان",
                        subtitle = "تعديل عنوان الصيدلية",
                        onClick = {}
                    )
                    SettingsItem(
                        icon = Icons.Default.Phone,
                        title = "رقم التواصل",
                        subtitle = "تعديل رقم الهاتف",
                        onClick = {}
                    )
                }
            }

            // Automation Rules
            item {
                SettingsSectionHeader("أتمتة العمليات")
            }
            item {
                SettingsCard {
                    SettingsItem(
                        icon = Icons.Default.AutoAwesome,
                        title = "قواعد الأتمتة",
                        subtitle = "تعديل، تعطيل، أو إعادة برمجة المهام",
                        onClick = { showAutomationSettings = true }
                    )
                    SettingsItem(
                        icon = Icons.Default.Sync,
                        title = "مزامنة السحابة",
                        subtitle = "النسخ الاحتياطي التلقائي",
                        onClick = {}
                    )
                    SettingsItem(
                        icon = Icons.Default.Schedule,
                        title = "جدولة المهام",
                        subtitle = "أوقات تشغيل العمليات الخلفية",
                        onClick = {}
                    )
                }
            }

            // Prescription Settings
            item {
                SettingsSectionHeader("إعدادات الوصفات")
            }
            item {
                SettingsCard {
                    var safetyDays by remember { mutableStateOf(3) }
                    SettingsItemWithSlider(
                        icon = Icons.Default.Alarm,
                        title = "مدة التنبيه قبل النفاد",
                        subtitle = "$safetyDays أيام قبل انتهاء الدواء",
                        value = safetyDays.toFloat(),
                        onValueChange = { safetyDays = it.toInt() },
                        valueRange = 1f..7f
                    )
                    SettingsItem(
                        icon = Icons.Default.Message,
                        title = "قناة التذكير",
                        subtitle = "واتساب",
                        onClick = {}
                    )
                }
            }

            // Security
            item {
                SettingsSectionHeader("الأمان")
            }
            item {
                SettingsCard {
                    SettingsToggleItem(
                        icon = Icons.Default.Fingerprint,
                        title = "القفل بالبصمة",
                        subtitle = "فتح التطبيق بالبصمة",
                        checked = true,
                        onCheckedChange = {}
                    )
                    SettingsToggleItem(
                        icon = Icons.Default.Visibility,
                        title = "إخفاء الأسعار",
                        subtitle = "إخفاء أسعار الشراء عن الموظفين",
                        checked = false,
                        onCheckedChange = {}
                    )
                    SettingsItem(
                        icon = Icons.Default.Lock,
                        title = "تغيير رمز المرور",
                        subtitle = "تحديث كلمة المرور",
                        onClick = { showSecuritySettings = true }
                    )
                }
            }

            // Appearance
            item {
                SettingsSectionHeader("المظهر")
            }
            item {
                SettingsCard {
                    SettingsToggleItem(
                        icon = Icons.Default.DarkMode,
                        title = "الوضع الليلي",
                        subtitle = "تبديل تلقائي",
                        checked = false,
                        onCheckedChange = {}
                    )
                    SettingsItem(
                        icon = Icons.Default.Language,
                        title = "اللغة",
                        subtitle = "العربية (RTL)",
                        onClick = {}
                    )
                }
            }

            // About
            item {
                SettingsSectionHeader("حول التطبيق")
            }
            item {
                SettingsCard {
                    SettingsItem(
                        icon = Icons.Default.Info,
                        title = "الإصدار",
                        subtitle = "Q-Pharma AI v1.0.0",
                        onClick = {}
                    )
                    SettingsItem(
                        icon = Icons.Default.Help,
                        title = "مركز المساعدة",
                        subtitle = "دليل الاستخدام والدعم",
                        onClick = {}
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(40.dp)) }
        }
    }

    if (showAutomationSettings) {
        AutomationRulesDialog(onDismiss = { showAutomationSettings = false })
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = QPharmaColors.TextSecondary,
        modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
    )
}

@Composable
private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Column(modifier = Modifier.padding(4.dp)) {
            content()
        }
    }
}

@Composable
private fun SettingsItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = QPharmaColors.Primary, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium, fontSize = 15.sp)
            Text(subtitle, fontSize = 12.sp, color = QPharmaColors.TextSecondary)
        }
        Icon(Icons.Default.ChevronLeft, null, tint = QPharmaColors.TextSecondary)
    }
}

@Composable
private fun SettingsToggleItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = QPharmaColors.Primary, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium, fontSize = 15.sp)
            Text(subtitle, fontSize = 12.sp, color = QPharmaColors.TextSecondary)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = QPharmaColors.Primary,
                checkedTrackColor = QPharmaColors.Primary.copy(alpha = 0.5f)
            )
        )
    }
}

@Composable
private fun SettingsItemWithSlider(
    icon: ImageVector,
    title: String,
    subtitle: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>
) {
    Column(modifier = Modifier.padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = QPharmaColors.Primary, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                Text(subtitle, fontSize = 12.sp, color = QPharmaColors.TextSecondary)
            }
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = valueRange.endInclusive.toInt() - valueRange.start.toInt() - 1,
            colors = SliderDefaults.colors(
                thumbColor = QPharmaColors.Primary,
                activeTrackColor = QPharmaColors.Primary
            ),
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}

@Composable
private fun AutomationRulesDialog(onDismiss: () -> Unit) {
    val rules = listOf(
        AutomationRuleItem("مزامنة المخزون", "كل 6 ساعات", true),
        AutomationRuleItem("تحويل التقارير", "يومياً الساعة 12 ص", true),
        AutomationRuleItem("فحص صلاحية الأدوية", "يومياً الساعة 8 ص", true),
        AutomationRuleItem("تصدير Excel", "أسبوعياً", false),
        AutomationRuleItem("تحليل AI للمخزون", "شهرياً", true)
    )

    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = QPharmaColors.Background),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    "قواعد الأتمتة",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))

                rules.forEach { rule ->
                    var isActive by remember { mutableStateOf(rule.isActive) }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(rule.name, fontWeight = FontWeight.Medium)
                            Text(rule.schedule, fontSize = 12.sp, color = QPharmaColors.TextSecondary)
                        }
                        Switch(
                            checked = isActive,
                            onCheckedChange = { isActive = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = QPharmaColors.Primary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("حفظ التغييرات")
                }
            }
        }
    }
}

data class AutomationRuleItem(
    val name: String,
    val schedule: String,
    val isActive: Boolean
)

//================================================================================
// FILE: ui/screens/supplier/SupplierScreen.kt
//================================================================================
package com.qpharma.ai.ui.screens.supplier

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qpharma.ai.data.entity.Supplier
import com.qpharma.ai.ui.theme.QPharmaColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SupplierScreen(
    onNavigateBack: () -> Unit = {}
) {
    var showNewReceipt by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الموردين", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = QPharmaColors.Background
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showNewReceipt = true },
                containerColor = QPharmaColors.Primary,
                icon = { Icon(Icons.Default.CameraAlt, null) },
                text = { Text("سند سداد") }
            )
        },
        containerColor = QPharmaColors.Background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Pending receipts section
            item {
                Text(
                    "سندات بانتظار الموافقة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            items(2) { index ->
                PendingReceiptCard(
                    supplierName = "مؤسسة الصحة الطبية",
                    amount = 250000.0,
                    reference = "CR-20260721-001",
                    onApprove = { /* Approve */ },
                    onReject = { /* Reject */ }
                )
            }

            // Suppliers list
            item {
                Text(
                    "قائمة الموردين",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 16.dp)
                )
            }

            items(5) { index ->
                SupplierCard(
                    supplier = Supplier(
                        id = index.toLong(),
                        name = "مورد ${index + 1}",
                        balance = (100000..500000).random().toDouble()
                    )
                )
            }
        }
    }

    if (showNewReceipt) {
        NewReceiptDialog(onDismiss = { showNewReceipt = false })
    }
}

@Composable
private fun PendingReceiptCard(
    supplierName: String,
    amount: Double,
    reference: String,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = QPharmaColors.Warning.copy(alpha = 0.08f)
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            QPharmaColors.Warning.copy(alpha = 0.3f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(QPharmaColors.Warning.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Receipt, null, tint = QPharmaColors.Warning)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(supplierName, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    Text("رقم الحوالة: $reference", fontSize = 12.sp, color = QPharmaColors.TextSecondary)
                }
                Text(
                    "$amount ر.ي",
                    fontWeight = FontWeight.Bold,
                    color = QPharmaColors.Primary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onApprove,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = QPharmaColors.Success)
                ) {
                    Icon(Icons.Default.Check, null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("موافقة", fontSize = 13.sp)
                }
                OutlinedButton(
                    onClick = onReject,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Close, null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("رفض", fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun SupplierCard(supplier: Supplier) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(QPharmaColors.Primary.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Business, null, tint = QPharmaColors.Primary)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(supplier.name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(
                    "رصيد: ${supplier.balance} ر.ي",
                    fontSize = 13.sp,
                    color = if (supplier.balance > 0) QPharmaColors.Error else QPharmaColors.Success
                )
            }
            Icon(Icons.Default.ChevronLeft, null, tint = QPharmaColors.TextSecondary)
        }
    }
}

@Composable
private fun NewReceiptDialog(onDismiss: () -> Unit) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "سند سداد جديد",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "صور إشعار التحويل وسيقوم AI باستخراج البيانات تلقائياً",
                    style = MaterialTheme.typography.bodyMedium,
                    color = QPharmaColors.TextSecondary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                Spacer(modifier = Modifier.height(24.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(QPharmaColors.SurfaceVariant)
                        .clickable { /* Open camera */ },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.CameraAlt,
                            null,
                            tint = QPharmaColors.Primary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("اضغط للتصوير", color = QPharmaColors.Primary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("إلغاء")
                }
            }
        }
    }
}

//================================================================================
// FILE: ui/screens/vision/VisionChatScreen.kt
//================================================================================
package com.qpharma.ai.ui.screens.vision

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qpharma.ai.ui.theme.QPharmaColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VisionChatScreen(
    screenType: String,
    onDismiss: () -> Unit = {}
) {
    var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
    var inputText by remember { mutableStateOf("") }
    var isAiTyping by remember { mutableStateOf(false) }

    // Initial greeting based on screen
    LaunchedEffect(Unit) {
        val greeting = when (screenType) {
            "dashboard" -> "مرحباً! أنا مساعد Q-Pharma AI. كيف يمكنني مساعدتك اليوم؟ يمكنني قراءة شاشتك الحالية والإجابة على استفساراتك."
            "prescription" -> "أنا هنا لمساعدتك في معالجة الوصفات. يمكنك تصوير الوصفة أو وصفها صوتياً وسأقوم بتحليلها."
            "sales" -> "هل تحتاج مساعدة في إنشاء فاتورة أو فحص تداخل دوائي؟"
            else -> "مرحباً! كيف يمكنني مساعدتك؟"
        }
        messages = listOf(ChatMessage("ai", greeting))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(QPharmaColors.Success)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("مساعد Q-Pharma AI", fontWeight = FontWeight.Bold)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, "إغلاق")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = QPharmaColors.Background
                )
            )
        },
        containerColor = QPharmaColors.Background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Messages
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages) { message ->
                    ChatBubble(message = message)
                }

                if (isAiTyping) {
                    item {
                        Row {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(QPharmaColors.Primary.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.SmartToy,
                                    null,
                                    tint = QPharmaColors.Primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(QPharmaColors.Surface)
                                    .padding(12.dp)
                            ) {
                                Text("جاري الكتابة...", color = QPharmaColors.TextSecondary)
                            }
                        }
                    }
                }
            }

            // Input area
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                colors = CardDefaults.cardColors(containerColor = QPharmaColors.Surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { /* Camera vision */ }) {
                        Icon(Icons.Default.CameraAlt, null, tint = QPharmaColors.Primary)
                    }

                    IconButton(onClick = { /* Voice input */ }) {
                        Icon(Icons.Default.Mic, null, tint = QPharmaColors.Primary)
                    }

                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = { Text("اكتب رسالتك أو استخدم الأوامر الصوتية...") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        singleLine = true
                    )

                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                messages = messages + ChatMessage("user", inputText)
                                inputText = ""
                                isAiTyping = true
                                // Simulate AI response
                                kotlinx.coroutines.GlobalScope.launch {
                                    kotlinx.coroutines.delay(1500)
                                    isAiTyping = false
                                    messages = messages + ChatMessage("ai", "فهمت طلبك! سأقوم بمساعدتك في ذلك.")
                                }
                            }
                        },
                        enabled = inputText.isNotBlank()
                    ) {
                        Icon(Icons.Default.Send, null, tint = QPharmaColors.Primary)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(message: ChatMessage) {
    val isUser = message.sender == "user"

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(QPharmaColors.Primary.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.SmartToy,
                    null,
                    tint = QPharmaColors.Primary,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Box(
            modifier = Modifier
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                )
                .background(
                    if (isUser) QPharmaColors.Primary
                    else QPharmaColors.Surface
                )
                .padding(12.dp)
                .widthIn(max = 280.dp)
        ) {
            Text(
                message.text,
                color = if (isUser) Color.White else QPharmaColors.TextPrimary,
                fontSize = 14.sp
            )
        }
    }
}

data class ChatMessage(val sender: String, val text: String)

//================================================================================
// FILE: di/AppModule.kt (Hilt Dependency Injection)
//================================================================================
package com.qpharma.ai.di

import android.content.Context
import androidx.room.Room
import com.qpharma.ai.data.database.QPharmaDatabase
import com.qpharma.ai.data.dao.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabasePassphrase(): String {
        // In production, derive from user password + device binding
        return "QPharmaSecureKey2024!"
    }

    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context,
        passphrase: String
    ): QPharmaDatabase {
        val factory = SupportFactory(SQLiteDatabase.getBytes(passphrase.toCharArray()))

        return Room.databaseBuilder(
            context,
            QPharmaDatabase::class.java,
            "qpharma_encrypted.db"
        )
            .openHelperFactory(factory)
            .build()
    }

    @Provides
    fun providePatientDao(database: QPharmaDatabase): PatientDao = database.patientDao()

    @Provides
    fun provideProductDao(database: QPharmaDatabase): ProductDao = database.productDao()

    @Provides
    fun provideInvoiceDao(database: QPharmaDatabase): InvoiceDao = database.invoiceDao()

    @Provides
    fun providePrescriptionDao(database: QPharmaDatabase): PrescriptionDao = database.prescriptionDao()

    @Provides
    fun provideMedicationReminderDao(database: QPharmaDatabase): MedicationReminderDao = 
        database.medicationReminderDao()

    @Provides
    fun provideDocumentDao(database: QPharmaDatabase): DocumentDao = database.documentDao()

    @Provides
    fun provideSupplierDao(database: QPharmaDatabase): SupplierDao = database.supplierDao()

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            })
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }
}
