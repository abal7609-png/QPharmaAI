
//================================================================================
// FILE: ai/PrescriptionAIProcessor.kt
//================================================================================
package com.qpharma.ai.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.arabic.ArabicTextRecognizerOptions
import com.qpharma.ai.data.entity.PrescriptionItemData
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * AI Engine for processing prescriptions via multiple input methods:
 * - Camera/OCR (Arabic + English text recognition)
 * - Voice (Speech-to-Text with Arabic NLP)
 * - PDF (Text extraction from medical documents)
 * 
 * Uses ML Kit for on-device processing (Offline-First)
 * Falls back to Cloud AI (Gemini/GPT-4o) when online
 */
@Singleton
class PrescriptionAIProcessor @Inject constructor(
    @ApplicationContext private val context: Context,
    private val cloudAIClient: CloudAIClient,
    private val arabicNLP: ArabicNLPParser
) {

    private val textRecognizer by lazy {
        TextRecognition.getClient(ArabicTextRecognizerOptions.Builder().build())
    }

    /**
     * Extract prescription data from image (camera or PDF page)
     * Primary method: On-device ML Kit OCR (works offline)
     * Fallback: Cloud Vision API for complex handwriting
     */
    suspend fun extractFromImage(imagePath: String): List<PrescriptionItemData> {
        return withContext(Dispatchers.IO) {
            try {
                val bitmap = BitmapFactory.decodeFile(imagePath)
                    ?: throw IllegalArgumentException("Cannot decode image: $imagePath")

                val image = InputImage.fromBitmap(bitmap, 0)
                val visionText = textRecognizer.process(image).await()

                val extractedText = visionText.text

                if (extractedText.isBlank()) {
                    // Fallback to cloud AI for handwritten prescriptions
                    return@withContext extractFromCloud(imagePath)
                }

                parsePrescriptionText(extractedText)

            } catch (e: Exception) {
                // Fallback to cloud processing
                extractFromCloud(imagePath)
            }
        }
    }

    /**
     * Extract prescription data from voice recording
     * Uses SpeechRecognizer API + Arabic NLP parsing
     */
    suspend fun extractFromVoice(voicePath: String): List<PrescriptionItemData> {
        return withContext(Dispatchers.IO) {
            val transcription = arabicNLP.transcribeAudio(voicePath)
            parsePrescriptionText(transcription)
        }
    }

    /**
     * Cloud AI fallback for complex cases (handwriting, poor quality images)
     */
    private suspend fun extractFromCloud(imagePath: String): List<PrescriptionItemData> {
        return cloudAIClient.analyzePrescriptionImage(imagePath)
    }

    /**
     * Core parsing logic: Converts raw text into structured prescription items
     * Handles both Arabic and English medical terminology
     */
    private fun parsePrescriptionText(text: String): List<PrescriptionItemData> {
        val items = mutableListOf<PrescriptionItemData>()
        val lines = text.split("\n".toRegex())

        var currentDrug: String? = null
        var currentConcentration: String? = null
        var currentDosage: String? = null
        var currentFrequency: String? = null
        var currentPackageQty: Int? = null

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isBlank()) continue

            // Drug name detection (Arabic or English)
            when {
                // Arabic drug patterns
                trimmed.contains(Regex("(قرص|كبسولة|شراب|حقنة|مرهم|قطرة)")) -> {
                    if (currentDrug != null) {
                        items.add(buildItem(currentDrug, currentConcentration, 
                            currentDosage, currentFrequency, currentPackageQty))
                    }
                    currentDrug = extractDrugName(trimmed)
                    currentPackageQty = extractPackageQuantity(trimmed)
                }
                // English drug patterns
                trimmed.contains(Regex("(tablet|capsule|syrup|injection|cream|drops)", 
                    RegexOption.IGNORE_CASE)) -> {
                    if (currentDrug != null) {
                        items.add(buildItem(currentDrug, currentConcentration,
                            currentDosage, currentFrequency, currentPackageQty))
                    }
                    currentDrug = extractDrugName(trimmed)
                    currentPackageQty = extractPackageQuantity(trimmed)
                }
                // Concentration pattern: 500mg, 10ml, etc.
                trimmed.contains(Regex("\d+\s*(mg|ml|g|mcg|iu)", RegexOption.IGNORE_CASE)) -> {
                    currentConcentration = extractConcentration(trimmed)
                }
                // Dosage pattern
                trimmed.contains(Regex("(حبة|قرص|ملعقة|حقنة|مرة|يوميا|daily|times)", 
                    RegexOption.IGNORE_CASE)) -> {
                    currentDosage = extractDosage(trimmed)
                    currentFrequency = extractFrequency(trimmed)
                }
            }
        }

        // Add last item
        if (currentDrug != null) {
            items.add(buildItem(currentDrug, currentConcentration,
                currentDosage, currentFrequency, currentPackageQty))
        }

        return items
    }

    private fun extractDrugName(line: String): String {
        // Remove common suffixes and clean the name
        return line.replace(Regex("\d+\s*(mg|ml|g|mcg).*"), "")
            .replace(Regex("(قرص|كبسولة|شراب|حقنة|مرهم|قطرة|tablet|capsule|syrup|injection|cream|drops)", 
                RegexOption.IGNORE_CASE), "")
            .trim()
    }

    private fun extractConcentration(line: String): String {
        val match = Regex("(\d+\s*(mg|ml|g|mcg|iu))", RegexOption.IGNORE_CASE).find(line)
        return match?.value ?: ""
    }

    private fun extractPackageQuantity(line: String): Int? {
        // Match patterns like "علبة 60" or "60 قرص"
        val match = Regex("(\d+)\s*(قرص|كبسولة|حبة|tablet|capsule)", 
            RegexOption.IGNORE_CASE).find(line)
        return match?.groupValues?.get(1)?.toIntOrNull()
    }

    private fun extractDosage(line: String): String {
        // "حبتين" → "2", "قرص واحد" → "1"
        return when {
            line.contains("حبتين") || line.contains("قرصين") -> "2"
            line.contains("ثلاث") || line.contains("3") -> "3"
            line.contains("أربع") || line.contains("4") -> "4"
            line.contains("واحد") || line.contains("1") -> "1"
            else -> "1"
        }
    }

    private fun extractFrequency(line: String): String {
        return when {
            line.contains("3") && line.contains("يوم") -> "3 مرات يومياً"
            line.contains("2") && line.contains("يوم") -> "مرتين يومياً"
            line.contains("مرة") && line.contains("يوم") -> "مرة يومياً"
            line.contains("قبل النوم") || line.contains("bedtime") -> "قبل النوم"
            line.contains("صباحاً") || line.contains("morning") -> "صباحاً"
            else -> "حسب الحاجة"
        }
    }

    private fun buildItem(
        drugName: String,
        concentration: String?,
        dosage: String?,
        frequency: String?,
        packageQty: Int?
    ): PrescriptionItemData {
        return PrescriptionItemData(
            drugName = drugName,
            concentration = concentration,
            quantity = 1,
            dosage = dosage,
            frequency = frequency,
            packageQty = packageQty ?: 30 // Default to 30 if not specified
        )
    }
}

//================================================================================
// FILE: ai/CloudAIClient.kt
//================================================================================
package com.qpharma.ai.ai

import com.qpharma.ai.data.entity.PrescriptionItemData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Cloud AI client for fallback processing
 * Supports: Gemini Vision API, OpenAI GPT-4o Vision
 */
@Singleton
class CloudAIClient @Inject constructor(
    private val okHttpClient: OkHttpClient
) {

    private val geminiApiKey = "YOUR_GEMINI_API_KEY"
    private val geminiEndpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"

    suspend fun analyzePrescriptionImage(imagePath: String): List<PrescriptionItemData> {
        return withContext(Dispatchers.IO) {
            val file = File(imagePath)
            val requestBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", file.name, file.asRequestBody("image/jpeg".toMediaType()))
                .addFormDataPart("prompt", buildPrescriptionPrompt())
                .build()

            val request = Request.Builder()
                .url("$geminiEndpoint?key=$geminiApiKey")
                .post(requestBody)
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            parseCloudResponse(responseBody)
        }
    }

    private fun buildPrescriptionPrompt(): String {
        return """
            Extract all medications from this prescription image.
            For each medication, provide:
            1. Drug name (Arabic or English)
            2. Concentration (e.g., 500mg)
            3. Quantity in package (e.g., 30 tablets)
            4. Dosage (e.g., 1 tablet)
            5. Frequency (e.g., 3 times daily)

            Return as JSON array:
            [
              {
                "drugName": "...",
                "concentration": "...",
                "packageQty": 30,
                "dosage": "1",
                "frequency": "3 times daily"
              }
            ]
        """.trimIndent()
    }

    private fun parseCloudResponse(responseBody: String): List<PrescriptionItemData> {
        return try {
            val json = JSONObject(responseBody)
            val candidates = json.getJSONArray("candidates")
            val content = candidates.getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")

            // Extract JSON from markdown code block if present
            val jsonStr = content.replace("```json", "").replace("```", "").trim()
            val jsonArray = org.json.JSONArray(jsonStr)

            List(jsonArray.length()) { i ->
                val obj = jsonArray.getJSONObject(i)
                PrescriptionItemData(
                    drugName = obj.getString("drugName"),
                    concentration = obj.optString("concentration", null),
                    quantity = 1,
                    dosage = obj.optString("dosage", "1"),
                    frequency = obj.optString("frequency", "daily"),
                    packageQty = obj.optInt("packageQty", 30)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}

//================================================================================
// FILE: ai/ArabicNLPParser.kt
//================================================================================
package com.qpharma.ai.ai

import android.content.Context
import android.speech.SpeechRecognizer
import android.speech.RecognizerIntent
import android.content.Intent
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.suspendCancellableCoroutine
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

/**
 * Arabic Natural Language Processing for voice inputs
 * Handles Arabic medical terminology, numbers, and dosage instructions
 */
@Singleton
class ArabicNLPParser @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val speechRecognizer: SpeechRecognizer? = SpeechRecognizer.createSpeechRecognizer(context)

    /**
     * Transcribe audio file to Arabic text using device SpeechRecognizer
     */
    suspend fun transcribeAudio(audioPath: String): String {
        return suspendCancellableCoroutine { continuation ->
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA") // Arabic (Saudi)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }

            speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    continuation.resume("")
                }
                override fun onResults(results: android.os.Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    continuation.resume(matches?.firstOrNull() ?: "")
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {}
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
            })

            speechRecognizer?.startListening(intent)

            continuation.invokeOnCancellation {
                speechRecognizer?.destroy()
            }
        }
    }

    /**
     * Parse Arabic dosage text into structured data
     * Example: "حبتين ثلاث مرات يومياً لمدة أسبوع" → structured dosage
     */
    fun parseArabicDosage(text: String): Map<String, Any> {
        val result = mutableMapOf<String, Any>()

        // Number words to digits
        val numberMap = mapOf(
            "واحد" to 1, "حبة" to 1, "قرص" to 1,
            "حبتين" to 2, "قرصين" to 2, "اثنان" to 2,
            "ثلاث" to 3, "ثلاثة" to 3, "أربع" to 4, "أربعة" to 4,
            "خمس" to 5, "خمسة" to 5
        )

        // Extract dosage count
        val dosagePattern = Regex("(\d+|واحد|حبة|حبتين|قرص|قرصين|ثلاث|أربع|خمس)")
        val dosageMatch = dosagePattern.find(text)
        result["dosage"] = numberMap[dosageMatch?.value] ?: 1

        // Extract frequency
        result["frequency"] = when {
            text.contains("ثلاث مرات") || text.contains("3 مرات") -> "3 مرات يومياً"
            text.contains("مرتين") || text.contains("2 مرة") -> "مرتين يومياً"
            text.contains("مرة واحدة") || text.contains("مرة يومياً") -> "مرة يومياً"
            text.contains("قبل النوم") -> "قبل النوم"
            text.contains("مع الوجبات") -> "مع الوجبات"
            else -> "حسب الحاجة"
        }

        // Extract duration
        val durationPattern = Regex("(\d+)\s*(يوم|أسبوع|شهر)")
        val durationMatch = durationPattern.find(text)
        result["duration"] = durationMatch?.groupValues?.get(1)?.toIntOrNull() ?: 7
        result["durationUnit"] = durationMatch?.groupValues?.get(2) ?: "يوم"

        return result
    }
}

//================================================================================
// FILE: ai/DocumentProcessor.kt
//================================================================================
package com.qpharma.ai.ai

import android.content.Context
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.qpharma.ai.data.entity.Document
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.poi.ss.usermodel.WorkbookFactory
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Document Processing Engine
 * Handles: PDF → Excel conversion, Invoice capture, Table extraction
 * Supports Arabic + English bilingual processing
 */
@Singleton
class DocumentProcessor @Inject constructor(
    @ApplicationContext private val context: Context,
    private val aiProcessor: PrescriptionAIProcessor
) {

    /**
     * Convert PDF to structured Excel file
     * Handles large PDFs (+1000 pages) with chunked processing
     */
    suspend fun pdfToExcel(
        pdfPath: String,
        onProgress: (Int, Int) -> Unit // (currentPage, totalPages)
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val file = File(pdfPath)
            val descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(descriptor)

            val totalPages = renderer.pageCount
            val workbook = XSSFWorkbook()
            val sheet = workbook.createSheet("Extracted Data")

            // Header row
            val headerRow = sheet.createRow(0)
            val headers = listOf("الصفحة", "النص المستخرج", "الصنف", "الكمية", "السعر", "الملاحظات")
            headers.forEachIndexed { index, header ->
                headerRow.createCell(index).setCellValue(header)
            }

            var rowIndex = 1

            // Process pages in chunks to avoid memory issues
            val chunkSize = 50
            for (chunkStart in 0 until totalPages step chunkSize) {
                val chunkEnd = minOf(chunkStart + chunkSize, totalPages)

                for (pageIndex in chunkStart until chunkEnd) {
                    val page = renderer.openPage(pageIndex)

                    // Extract text using OCR
                    val bitmap = android.graphics.Bitmap.createBitmap(
                        page.width, page.height, android.graphics.Bitmap.Config.ARGB_8888
                    )
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_TEXT)

                    // Save temp image for OCR
                    val tempImage = File(context.cacheDir, "pdf_page_$pageIndex.png")
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, 
                        FileOutputStream(tempImage))

                    // OCR processing
                    val extractedText = aiProcessor.extractFromImage(tempImage.absolutePath)
                        .joinToString("\n") { it.drugName }

                    // Add to Excel
                    val row = sheet.createRow(rowIndex++)
                    row.createCell(0).setCellValue((pageIndex + 1).toDouble())
                    row.createCell(1).setCellValue(extractedText)

                    // Clean up
                    tempImage.delete()
                    page.close()
                    bitmap.recycle()

                    onProgress(pageIndex + 1, totalPages)
                }

                // Force garbage collection between chunks
                System.gc()
            }

            renderer.close()
            descriptor.close()

            // Save Excel file
            val excelFile = File(context.getExternalFilesDir(null), 
                "extracted_${System.currentTimeMillis()}.xlsx")
            FileOutputStream(excelFile).use { workbook.write(it) }
            workbook.close()

            Result.success(excelFile.absolutePath)

        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Process captured invoice image
     * Extracts: items, quantities, prices, supplier info
     */
    suspend fun processInvoiceImage(imagePath: String): InvoiceExtractionResult {
        return withContext(Dispatchers.IO) {
            val extractedData = aiProcessor.extractFromImage(imagePath)

            // Additional invoice-specific parsing
            val invoiceData = parseInvoiceSpecifics(extractedData)

            InvoiceExtractionResult(
                items = invoiceData,
                confidence = 0.85f,
                rawText = ""
            )
        }
    }

    private fun parseInvoiceSpecifics(items: List<PrescriptionItemData>): List<InvoiceItemData> {
        return items.map { item ->
            InvoiceItemData(
                itemName = item.drugName,
                quantity = item.quantity,
                unitPrice = 0.0, // Will be filled from price list
                totalPrice = 0.0
            )
        }
    }

    /**
     * Export data to Excel with voice editing support
     */
    suspend fun exportToExcel(
        data: List<Map<String, Any>>,
        fileName: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val workbook = XSSFWorkbook()
            val sheet = workbook.createSheet("Data")

            if (data.isNotEmpty()) {
                // Headers
                val headerRow = sheet.createRow(0)
                data[0].keys.forEachIndexed { index, key ->
                    headerRow.createCell(index).setCellValue(key)
                }

                // Data rows
                data.forEachIndexed { rowIndex, rowData ->
                    val row = sheet.createRow(rowIndex + 1)
                    rowData.values.forEachIndexed { colIndex, value ->
                        when (value) {
                            is Number -> row.createCell(colIndex).setCellValue(value.toDouble())
                            is String -> row.createCell(colIndex).setCellValue(value)
                            else -> row.createCell(colIndex).setCellValue(value.toString())
                        }
                    }
                }
            }

            val file = File(context.getExternalFilesDir(null), "$fileName.xlsx")
            FileOutputStream(file).use { workbook.write(it) }
            workbook.close()

            Result.success(file.absolutePath)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

data class InvoiceExtractionResult(
    val items: List<InvoiceItemData>,
    val confidence: Float,
    val rawText: String
)

data class InvoiceItemData(
    val itemName: String,
    val quantity: Int,
    val unitPrice: Double,
    val totalPrice: Double
)
