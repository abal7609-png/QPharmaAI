# دليل بناء Q-Pharma AI APK - خطوة بخطوة

## الطريقة الأولى: GitHub Actions (الأسهل - لا يحتاج برمجة)

### الخطوة 1: أنشئ حساب GitHub (مجاني)
```
1. افتح: https://github.com/signup
2. اكتب بريدك الإلكتروني
3. أنشئ كلمة مرور
4. أكد بريدك الإلكتروني
5. اختر "Free" plan (مجاني)
```

### الخطوة 2: أنشئ مستودع جديد (Repository)
```
1. اضغط الزر الأخضر "+" في الأعلى
2. اختر "New repository"
3. اسم المستودع: QPharmaAI
4. اختر "Public" (مجاني)
5. اضغط "Create repository"
```

### الخطوة 3: ارفع المشروع
```
1. في صفحة المستودع الجديد، اضغط "uploading an existing file"
2. اسحب ملف ZIP (QPharmaAI_Project.zip) أو اضغط "choose your files"
3. انتظر رفع الملفات (قد يستغرق دقيقتين)
4. اكتب في "Commit changes": "Initial project upload"
5. اضغط "Commit changes"
```

### الخطوة 4: انتظر البناء التلقائي
```
1. اذهب إلى تبويب "Actions" في الأعلى
2. ستجد workflow اسمه "Build Q-Pharma AI APK"
3. اضغط عليه
4. انتظر 5-10 دقائق حتى يكتمل (اللون الأخضر = نجاح)
```

### الخطوة 5: حمل APK
```
1. بعد اكتمال البناء، اذهب إلى "Actions" → اضغط على آخر run
2. اسحل للأسفل إلى "Artifacts"
3. اضغط "QPharmaAI-Debug-APK" لتحميل الملف
4. الملف هو: app-debug.apk
```

### الخطوة 6: ثبت على هاتفك
```
1. انقل ملف APK إلى هاتفك (واتساب، تيليجرام، أو كابل)
2. على الهاتف، افتح الملف
3. اضغط "Install" (قد تحتاج تفعيل "Unknown sources")
4. افتح التطبيق!
```

---

## الطريقة الثانية: Android Studio (الأكثر تحكمًا)

### الخطوة 1: تحميل Android Studio
```
https://developer.android.com/studio
```
- اضغط "Download Android Studio"
- ثبت البرنامج (Next → Next → Finish)

### الخطوة 2: فتح المشروع
```
1. افتح Android Studio
2. اضغط "Open" (ليس New Project)
3. انتقل إلى مجلد QPharmaAI (المستخرج من ZIP)
4. اضغط "OK"
```

### الخطوة 3: انتظر المزامنة
```
- سيظهر "Gradle: Build Running" في الأسفل
- انتظر حتى يختفي (10-30 دقيقة أول مرة)
- إذا ظهر خطأ، اضغط: File → Sync Project with Gradle Files
```

### الخطوة 4: بناء APK
```
1. في القائمة العلوية: Build
2. اختر: Build Bundle(s) / APK(s)
3. اختر: Build APK(s)
4. انتظر حتى يكتمل
```

### الخطوة 5: جد APK
```
1. سيظهر إشعار "APK generated successfully"
2. اضغط على "locate" في الإشعار
3. أو اذهب إلى: QPharmaAI/app/build/outputs/apk/debug/
4. الملف: app-debug.apk
```

---

## الطريقة الثالثة: خدمات بناء APK أونلاين (أسرع)

### خدمة Codemagic (مجاني)
```
1. افتح: https://codemagic.io
2. سجل دخول بحساب GitHub
3. اختر مستودع QPharmaAI
4. اضغط "Start new build"
5. انتظر 5 دقائق
6. حمل APK
```

### خدمة Appcircle (مجاني)
```
1. افتح: https://appcircle.io
2. أنشئ حساب
3. اربط بـ GitHub
4. اختر المشروع
5. اضغط "Build"
```

---

## ⚠️ حل المشاكل الشائعة

### "Gradle sync failed"
```
File → Invalidate Caches → Invalidate and Restart
```

### "SDK not found"
```
Tools → SDK Manager → Install Android SDK 34
```

### "Out of memory"
```
افتح: gradle.properties
غير: org.gradle.jvmargs=-Xmx4096m
إلى:  org.gradle.jvmargs=-Xmx8192m
```

### "Java not found"
```
1. حمل JDK 17: https://adoptium.net
2. ثبته
3. في Android Studio: File → Settings → Build → Gradle → Set JDK path
```

---

## 📱 متطلبات الهاتف

| المواصفة | الحد الأدنى |
|----------|-------------|
| Android | 8.0 (API 26) |
| RAM | 3 GB |
| Storage | 200 MB فارغ |
| Camera | مطلوبة للتصوير |
| Microphone | مطلوب للصوت |

---

## 🆘 الدعم

إذا واجهت أي مشكلة:
1. صوّر الشاشة (Screenshot)
2. ارسلها مع وصف المشكلة
3. سأساعدك في الحل

---

**Q-Pharma AI v1.0.0** | نظام إدارة الصيدليات الذكي
